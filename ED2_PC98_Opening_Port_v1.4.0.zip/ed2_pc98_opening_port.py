#!/usr/bin/env python3
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import tempfile

APP_NAME = "ED2 PC-98 Opening Port"
VERSION = "1.4.0"
BACKUP_SUFFIX = ".pc98_opening_v14.bak"
KNOWN_G_OP1700_SHA256 = "4ca1212f5f7d7429204abccb8afb2e3fb52502c86e3b3b1a223d51514f087fd4"
KNOWN_G_OP2200_SHA256 = "d7a5f86efb3f3a5ff85c0b133a341274d02e94306bb6fc8c15b7b56db152bef1"

SEGMENT_ORDINAL = 0x1D
BASE_SEGMENT_LENGTH = 0x45E6
OLD_V12_TAIL_SIZE = 113
OLD_V12_MARKER = b"FLORA232"
TAIL_OFFSET = BASE_SEGMENT_LENGTH
OLD_V13_LOCAL_CODE = bytes.fromhex("601e0655bde800e81f00e89d10b9e8004de8190fe81200e8440fc606fa0b02e8d11be2ec5d071f61c3601e0636a1001d8ed836a102008ec031dbe89c3b36a104008ec0bb007de8903b36a1021d8ed836a106008ec031dbe87f3b36a108008ec0bb007de8733b071f61c3")
LOCAL_CODE = bytes.fromhex("601e0655bdc800e81f00e89d10b9c8004de8190fe81200e8440fc606fa0b02e8d11be2ec5d071f61c3601e0636a1001d8ed836a102008ec031dbe89c3b36a104008ec0bb007de8903b36a1021d8ed836a106008ec031dbe87f3b36a108008ec0bb007de8733b071f61c3")
TAIL_CODE = bytes.fromhex("bf501a81fdc800771683fd20723089e883e820e8450001deb9e800e84800c389e883e820e8340001deb9b00129e95589cde83200b9e80029e95de83b00c3b9200029e989e8e8130083c63001dee8390089deb9c80001e9e80c00c389c6c1e004c1e60601c6c3e30f51b91800f3a55983c62083c720e2f1c3e30e31c051b91800f3ab5983c720e2f4c3e31e5156b90c00f3a55e81c6000ab90c00f3a581ee000a83c63883c72059e2e2c3464c4f5241534352")
TAIL_MARKER = b"FLORASCR"
LOCAL_START_ABS = 0x0A0D
LOCAL_END_ABS = 0x0AB2

SCENE_ANCHOR = bytes.fromhex("B8 00 17 B2 50")
REL_SETUP_DI = 0xBC
REL_SETUP_SI = 0xBF
REL_INITIAL_CALL = 0xE1   # 0A07
REL_POST_CALL = 0xE4      # 0A0A
REL_LOCAL_START = 0xE7    # 0A0D
REL_LOCAL_END = 0x18C     # 0AB2
REL_LOOP_COUNT = 0xE7
REL_LOOP_DI = 0xEA
REL_LOOP_SI = 0xED
REL_LOOP_BLIT = 0xF6
REL_HEIGHTS = (0x114, 0x12F, 0x153, 0x16E)

ORIGINAL_SETUP_DI = bytes.fromhex("BF 50 1F")
ORIGINAL_SETUP_SI = bytes.fromhex("BE 80 3E")
ORIGINAL_INITIAL_CALL = bytes.fromhex("E8 25 00")
ORIGINAL_POST_CALL = bytes.fromhex("E8 AA 10")
ORIGINAL_LOOP_COUNT = bytes.fromhex("B9 C8 00")
ORIGINAL_LOOP_DI = ORIGINAL_SETUP_DI
ORIGINAL_LOOP_SI = ORIGINAL_SETUP_SI
ORIGINAL_LOOP_BLIT = bytes.fromhex("E8 10 00")
ORIGINAL_HEIGHT = bytes.fromhex("B9 C8 00")

V11_SETUP_DI = bytes.fromhex("BF 10 00")
V11_SETUP_SI = bytes.fromhex("BE 00 00")
V11_LOOP_BLIT = bytes.fromhex("90 90 90")
V11_HEIGHT = bytes.fromhex("B9 90 01")

V12_SETUP_DI = bytes.fromhex("BF 50 24")
V12_SETUP_SI = bytes.fromhex("BE 80 3E")
V12_LOOP_BLIT = bytes.fromhex("E8 10 00")
V12_HEIGHT = ORIGINAL_HEIGHT

PEOPLE_ORIGINAL = bytes.fromhex("75 CF EB 5B 90 B8 00 22 B2 42 E8")
PEOPLE_PATCHED  = bytes.fromhex("75 CF 90 90 90 B8 00 22 B2 42 E8")
PEOPLE_JUMP_REL = 2

BLOOD_TEMPLATE: tuple[int | None, ...] = (
    0xC6,0x44,0x06,None, 0xC6,0x44,0x08,None,
    0xC6,0x44,0x09,None, 0xC6,0x44,0x0B,None,
    0xC6,0x44,0x0C,None, 0xC6,0x44,0x0E,None,
)
BLOOD_VALUE_REL=(3,7,11,15,19,23)
BLOOD_RED_VALUES=(0,0,0,0,0,0)

class PortError(Exception):
    pass

@dataclass(frozen=True)
class Segment:
    ordinal:int
    table_entry:int
    file_offset:int
    length:int
    flags:int
    min_alloc:int

@dataclass(frozen=True)
class Analysis:
    root:Path
    opening:Path
    flora:Path
    people:Path|None
    flora_state:str
    people_state:str
    blood_values:tuple[int,int,int,int,int,int]|None
    opening_sha256:str
    flora_sha256:str
    segment_length:int
    relocation_count:int
    scene_offset:int


def sha256_file(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()


def atomic_write(path:Path,data:bytes)->None:
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=str(path.parent))
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def backup_once(path:Path)->Path:
    b=path.with_name(path.name+BACKUP_SUFFIX)
    if not b.exists(): shutil.copy2(path,b)
    return b


def resolve_root(path:Path)->tuple[Path,Path,Path,Path|None]:
    p=path.expanduser().resolve()
    if p.is_file() and p.name.upper()=='OPENING.EXE': root=p.parent
    elif p.is_dir(): root=p.parent if p.name.upper()=='GRP' and (p.parent/'OPENING.EXE').is_file() else p
    else: raise PortError('게임 폴더 또는 OPENING.EXE를 선택해야 합니다.')
    opening=root/'OPENING.EXE'; flora=root/'GRP'/'G_OP1700.BZP'; people=root/'GRP'/'G_OP2200.BZB'
    if not opening.is_file(): raise PortError(f'OPENING.EXE를 찾지 못했습니다: {opening}')
    if not flora.is_file(): raise PortError(f'G_OP1700.BZP를 찾지 못했습니다: {flora}')
    return root,opening,flora,(people if people.is_file() else None)


def parse_segments(exe:bytes)->list[Segment]:
    if len(exe)<0x40 or exe[:2]!=b'MZ': raise PortError('MZ 실행 파일이 아닙니다.')
    ne=struct.unpack_from('<I',exe,0x3C)[0]
    if ne+0x40>len(exe) or exe[ne:ne+2]!=b'NE': raise PortError('NE 헤더를 찾지 못했습니다.')
    count=struct.unpack_from('<H',exe,ne+0x1C)[0]
    table=ne+struct.unpack_from('<H',exe,ne+0x22)[0]
    shift=struct.unpack_from('<H',exe,ne+0x32)[0]
    out=[]
    for i in range(count):
        ent=table+i*8
        units,length,flags,min_alloc=struct.unpack_from('<HHHH',exe,ent)
        real=0x10000 if length==0 else length; off=units<<shift
        if off+real>len(exe): raise PortError(f'NE 세그먼트 {i+1}이 파일 범위를 벗어납니다.')
        out.append(Segment(i+1,ent,off,real,flags,min_alloc))
    return out


def relocation_blob(exe:bytes,seg:Segment)->tuple[int,bytes,list[int]]:
    if not (seg.flags & 0x0100): return 0,b'',[]
    p=seg.file_offset+seg.length
    if p+2>len(exe): raise PortError('세그먼트 재배치 표가 잘렸습니다.')
    count=struct.unpack_from('<H',exe,p)[0]; size=2+count*8
    if p+size>len(exe): raise PortError('세그먼트 재배치 항목이 잘렸습니다.')
    blob=exe[p:p+size]
    sources=[struct.unpack_from('<H',blob,2+i*8+2)[0] for i in range(count)]
    return count,blob,sources


def find_scene(block:bytes)->int:
    hits=[];start=0
    while True:
        i=block.find(SCENE_ANCHOR,start)
        if i<0: break
        hits.append(i);start=i+1
    if len(hits)!=1: raise PortError(f'G_OP1700 장면 시그니처가 정확히 한 곳이 아닙니다: {len(hits)}')
    return hits[0]


def near_target(block:bytes,at:int,opcode:int)->int|None:
    if at+3>len(block) or block[at]!=opcode: return None
    return at+3+struct.unpack_from('<h',block,at+1)[0]


def find_people_state(block:bytes)->str:
    a=block.find(PEOPLE_ORIGINAL); b=block.find(PEOPLE_PATCHED)
    if a>=0 and b<0:return 'skipped'
    if b>=0 and a<0:return 'enabled'
    return 'unknown'


def blood_values(block:bytes)->tuple[int,int,int,int,int,int]|None:
    hits=[]
    for off in range(len(block)-len(BLOOD_TEMPLATE)+1):
        if all(v is None or block[off+i]==v for i,v in enumerate(BLOOD_TEMPLATE)): hits.append(off)
    if len(hits)!=1:return None
    off=hits[0]
    return tuple(block[off+i] for i in BLOOD_VALUE_REL)  # type: ignore[return-value]


def flora_state(exe:bytes,segs:list[Segment])->tuple[str,int]:
    seg=segs[SEGMENT_ORDINAL-1]; block=exe[seg.file_offset:seg.file_offset+seg.length]; scene=find_scene(block)
    initial=scene+REL_INITIAL_CALL; post=scene+REL_POST_CALL
    if (seg.length==BASE_SEGMENT_LENGTH+len(TAIL_CODE)
        and block[scene+REL_LOCAL_START:scene+REL_LOCAL_START+len(LOCAL_CODE)]==LOCAL_CODE
        and block[TAIL_OFFSET:TAIL_OFFSET+len(TAIL_CODE)]==TAIL_CODE
        and near_target(block,initial,0xE8)==scene+REL_LOCAL_START
        and near_target(block,post,0xE9)==scene+REL_LOCAL_END):
        return 'pc98_smooth_200_preshift32',scene
    if (seg.length==BASE_SEGMENT_LENGTH+len(TAIL_CODE)
        and block[scene+REL_LOCAL_START:scene+REL_LOCAL_START+len(OLD_V13_LOCAL_CODE)]==OLD_V13_LOCAL_CODE
        and block[TAIL_OFFSET:TAIL_OFFSET+len(TAIL_CODE)]==TAIL_CODE
        and near_target(block,initial,0xE8)==scene+REL_LOCAL_START
        and near_target(block,post,0xE9)==scene+REL_LOCAL_END):
        return 'v13_smooth_232_black_start',scene
    if (seg.length==BASE_SEGMENT_LENGTH+OLD_V12_TAIL_SIZE
        and OLD_V12_MARKER in block[TAIL_OFFSET:TAIL_OFFSET+OLD_V12_TAIL_SIZE]
        and near_target(block,initial,0xE8)==TAIL_OFFSET):
        return 'v12_fixed_strip_flicker',scene
    di=block[scene+REL_SETUP_DI:scene+REL_SETUP_DI+3]
    si=block[scene+REL_SETUP_SI:scene+REL_SETUP_SI+3]
    loop=block[scene+REL_LOOP_BLIT:scene+REL_LOOP_BLIT+3]
    hs=[block[scene+r:scene+r+3] for r in REL_HEIGHTS]
    if di==V11_SETUP_DI and si==V11_SETUP_SI and loop==V11_LOOP_BLIT and all(x==V11_HEIGHT for x in hs):
        return 'v11_static_fullheight',scene
    if di==ORIGINAL_SETUP_DI and si==ORIGINAL_SETUP_SI and loop==ORIGINAL_LOOP_BLIT and all(x==ORIGINAL_HEIGHT for x in hs):
        return 'dos_200_scroll',scene
    if di==V12_SETUP_DI and si==V12_SETUP_SI and loop==V12_LOOP_BLIT and all(x==V12_HEIGHT for x in hs):
        return 'v12_partial_or_damaged',scene
    return 'unknown',scene


def analyze(path:Path)->Analysis:
    root,opening,flora,people=resolve_root(path); exe=opening.read_bytes(); segs=parse_segments(exe)
    if len(segs)<SEGMENT_ORDINAL:raise PortError('필요한 NE 세그먼트 0x1D가 없습니다.')
    st,scene=flora_state(exe,segs); seg=segs[SEGMENT_ORDINAL-1]; rc,_,_=relocation_blob(exe,seg)
    block=exe[seg.file_offset:seg.file_offset+seg.length]
    return Analysis(root,opening,flora,people,st,find_people_state(block),blood_values(block),sha256_file(opening),sha256_file(flora),seg.length,rc,scene)


def analysis_dict(a:Analysis)->dict:
    return {
        'tool_version':VERSION,'root':str(a.root),'opening':str(a.opening),'opening_sha256':a.opening_sha256,
        'flora_state':a.flora_state,'flora_scene':f'1D:{a.scene_offset:04X}',
        'segment_1d_length':a.segment_length,'segment_1d_relocation_count':a.relocation_count,
        'g_op1700_sha256':a.flora_sha256,'g_op1700_matches_verified_asset':a.flora_sha256==KNOWN_G_OP1700_SHA256,
        'people_state':a.people_state,'blood_values':None if a.blood_values is None else list(a.blood_values),
        'smooth_scroll':{
            'window':{'x':128,'y':84,'width':384,'height':232},
            'virtual_rows':432,'start_virtual_row':200,'end_virtual_row':0,'movement_frames':200,
            'upper_extension_rows':32,
            'behavior':'The animation starts 32 rows higher than v1.3, so the 384x232 window is full from frame 0; the upper extension still enters naturally during the final 32 frames.'
        }
    }


def normalize_original_scene(out:bytearray,seg:Segment,scene:int)->None:
    b=seg.file_offset+scene
    out[b+REL_SETUP_DI:b+REL_SETUP_DI+3]=ORIGINAL_SETUP_DI
    out[b+REL_SETUP_SI:b+REL_SETUP_SI+3]=ORIGINAL_SETUP_SI
    out[b+REL_LOOP_COUNT:b+REL_LOOP_COUNT+3]=ORIGINAL_LOOP_COUNT
    out[b+REL_LOOP_DI:b+REL_LOOP_DI+3]=ORIGINAL_LOOP_DI
    out[b+REL_LOOP_SI:b+REL_LOOP_SI+3]=ORIGINAL_LOOP_SI
    out[b+REL_LOOP_BLIT:b+REL_LOOP_BLIT+3]=ORIGINAL_LOOP_BLIT
    for r in REL_HEIGHTS: out[b+r:b+r+3]=ORIGINAL_HEIGHT


def inject_smooth_flora(exe:bytes)->bytes:
    segs=parse_segments(exe); seg=segs[SEGMENT_ORDINAL-1]; state,scene=flora_state(exe,segs)
    if state=='pc98_smooth_200_preshift32': return exe
    if state not in ('dos_200_scroll','v11_static_fullheight','v12_fixed_strip_flicker','v12_partial_or_damaged','v13_smooth_232_black_start'):
        raise PortError(f'지원하지 않는 플로라 코드 상태입니다: {state}')
    if SEGMENT_ORDINAL>=len(segs): raise PortError('세그먼트 0x1D 다음 영역을 찾을 수 없습니다.')
    if seg.length not in (BASE_SEGMENT_LENGTH,BASE_SEGMENT_LENGTH+OLD_V12_TAIL_SIZE,BASE_SEGMENT_LENGTH+len(TAIL_CODE)):
        raise PortError(f'세그먼트 0x1D 길이가 지원 범위와 다릅니다: 0x{seg.length:X}')
    count,fixups,sources=relocation_blob(exe,seg)
    local_lo=scene+REL_LOCAL_START; local_hi=scene+REL_LOCAL_END
    bad=[x for x in sources if local_lo<=x<local_hi]
    if bad: raise PortError(f'교체할 플로라 루틴 안에 NE 재배치 항목이 있습니다: {bad}')
    next_off=segs[SEGMENT_ORDINAL].file_offset
    required=len(TAIL_CODE)+len(fixups)
    capacity=next_off-(seg.file_offset+BASE_SEGMENT_LENGTH)
    if required>capacity: raise PortError(f'새 루틴과 재배치 표 공간이 부족합니다: 필요 {required}, 사용 가능 {capacity}')

    out=bytearray(exe)
    normalize_original_scene(out,seg,scene)
    # Replace the old per-frame blit body with the controller. The unused remainder
    # is filled with NOPs so v1.1/v1.2 leftovers cannot execute accidentally.
    local_file=seg.file_offset+local_lo
    out[local_file:seg.file_offset+local_hi]=b'\x90'*(local_hi-local_lo)
    out[local_file:local_file+len(LOCAL_CODE)]=LOCAL_CODE

    # Rebuild the tail from the verified original segment boundary. This upgrades
    # v1.2 in place and moves the original relocation table intact.
    old_base_end=seg.file_offset+BASE_SEGMENT_LENGTH
    out[old_base_end:next_off]=b'\0'*(next_off-old_base_end)
    out[old_base_end:old_base_end+len(TAIL_CODE)]=TAIL_CODE
    out[old_base_end+len(TAIL_CODE):old_base_end+len(TAIL_CODE)+len(fixups)]=fixups
    new_len=BASE_SEGMENT_LENGTH+len(TAIL_CODE)
    struct.pack_into('<H',out,seg.table_entry+2,new_len)
    struct.pack_into('<H',out,seg.table_entry+6,max(new_len,seg.min_alloc))
    newseg=Segment(seg.ordinal,seg.table_entry,seg.file_offset,new_len,seg.flags,max(new_len,seg.min_alloc))

    # Initial CALL -> local controller at 0A0D. Controller starts 32 rows higher and performs 200 one-row frames.
    call_at=newseg.file_offset+scene+REL_INITIAL_CALL
    call_target=scene+REL_LOCAL_START
    call_disp=call_target-(scene+REL_INITIAL_CALL+3)
    out[call_at:call_at+3]=b'\xE8'+struct.pack('<h',call_disp)
    # After controller returns, skip the obsolete original loop/blitter body.
    post_at=newseg.file_offset+scene+REL_POST_CALL
    post_target=scene+REL_LOCAL_END
    post_disp=post_target-(scene+REL_POST_CALL+3)
    out[post_at:post_at+3]=b'\xE9'+struct.pack('<h',post_disp)

    check=bytes(out); csegs=parse_segments(check); cseg=csegs[SEGMENT_ORDINAL-1]
    ccount,cfix,_=relocation_blob(check,cseg)
    if ccount!=count or cfix!=fixups: raise PortError('NE 재배치 표 보존 검증에 실패했습니다.')
    cstate,_=flora_state(check,csegs)
    if cstate!='pc98_smooth_200_preshift32': raise PortError('32픽셀 선행 이동 플로라 패치 검증에 실패했습니다.')
    return check


def patch_people(exe:bytes)->bytes:
    seg=parse_segments(exe)[SEGMENT_ORDINAL-1]; block=exe[seg.file_offset:seg.file_offset+seg.length]
    a=block.find(PEOPLE_ORIGINAL); b=block.find(PEOPLE_PATCHED)
    if b>=0 and a<0:return exe
    if a<0 or b>=0:raise PortError('쓰러진 사람 패치 위치를 고유하게 찾지 못했습니다.')
    out=bytearray(exe); p=seg.file_offset+a+PEOPLE_JUMP_REL; out[p:p+2]=b'\x90\x90'; return bytes(out)


def patch_blood(exe:bytes)->bytes:
    seg=parse_segments(exe)[SEGMENT_ORDINAL-1]; block=exe[seg.file_offset:seg.file_offset+seg.length]
    hits=[]
    for off in range(len(block)-len(BLOOD_TEMPLATE)+1):
        if all(v is None or block[off+i]==v for i,v in enumerate(BLOOD_TEMPLATE)):hits.append(off)
    if len(hits)!=1:raise PortError('피 색상 명령을 고유하게 찾지 못했습니다.')
    out=bytearray(exe); base=seg.file_offset+hits[0]
    for r,v in zip(BLOOD_VALUE_REL,BLOOD_RED_VALUES):out[base+r]=v
    return bytes(out)


def apply(path:Path,all_pc98:bool=False)->dict:
    before=analyze(path)
    if before.flora_sha256!=KNOWN_G_OP1700_SHA256:
        raise PortError('G_OP1700.BZP가 검증한 한국판/PC-98 공통 원본과 다릅니다. 다른 버전에는 적용하지 않습니다.')
    original=before.opening.read_bytes(); patched=inject_smooth_flora(original)
    if all_pc98:
        patched=patch_people(patched); patched=patch_blood(patched)
    backup=backup_once(before.opening)
    atomic_write(before.opening,patched)
    try:
        after=analyze(before.root)
        if after.flora_state!='pc98_smooth_200_preshift32':raise PortError('저장 후 플로라 상태가 올바르지 않습니다.')
        if all_pc98 and after.people_state!='enabled':raise PortError('저장 후 쓰러진 사람 상태가 올바르지 않습니다.')
        if all_pc98 and after.blood_values!=BLOOD_RED_VALUES:raise PortError('저장 후 피 색상이 올바르지 않습니다.')
    except Exception:
        atomic_write(before.opening,original); raise
    diffs=[i for i,(a,b) in enumerate(zip(original,patched)) if a!=b]
    return {'tool_version':VERSION,'backup':str(backup),'all_pc98':all_pc98,'changed_bytes':len(diffs),
            'opening_sha256_before':before.opening_sha256,'opening_sha256_after':after.opening_sha256,
            'before':analysis_dict(before),'after':analysis_dict(after)}


def restore(path:Path)->dict:
    root,opening,_,_=resolve_root(path); b=opening.with_name(opening.name+BACKUP_SUFFIX)
    if not b.is_file():raise PortError(f'백업 파일이 없습니다: {b}')
    atomic_write(opening,b.read_bytes());return analysis_dict(analyze(root))


class GUI:
    def __init__(self):
        import tkinter as tk
        from tkinter import ttk
        self.tk=tk; self.ttk=ttk; self.project=None
        self.root=tk.Tk(); self.root.title(f'{APP_NAME} v{VERSION}'); self.root.minsize(880,650)
        outer=ttk.Frame(self.root,padding=12);outer.pack(fill='both',expand=True)
        top=ttk.Frame(outer);top.pack(fill='x')
        ttk.Button(top,text='게임 폴더 열기',command=self.choose).pack(side='left')
        self.path=ttk.Label(top,text='OPENING.EXE와 GRP 폴더가 있는 위치를 선택하십시오.');self.path.pack(side='left',padx=10,fill='x',expand=True)
        why=ttk.LabelFrame(outer,text='v1.4 수정 방식',padding=10);why.pack(fill='x',pady=(12,8))
        ttk.Label(why,text='v1.3의 자연스러운 한 줄 이동은 유지하되 시작 위치를 32픽셀 미리 올립니다. 첫 프레임부터 384×232 창이 전부 그림으로 채워져 검은 레터박스가 생기지 않으며, 이후 200프레임 동안 한 줄씩 올라가 마지막 32프레임에는 머리 위 배경과 머리카락 전체가 자연스럽게 들어옵니다. 기존 쓰러진 사람/빨간 피 패치는 그대로 유지합니다.',wraplength=820,justify='left').pack(anchor='w')
        box=ttk.LabelFrame(outer,text='현재 파일 분석',padding=10);box.pack(fill='both',expand=True,pady=8)
        self.info=tk.Text(box,height=19,wrap='word',state='disabled');self.info.pack(fill='both',expand=True)
        buttons=ttk.Frame(outer);buttons.pack(fill='x',pady=(8,0))
        ttk.Button(buttons,text='플로라 32픽셀 선행 이동 적용',command=lambda:self.do_apply(False)).pack(side='left')
        ttk.Button(buttons,text='PC-98 오프닝 전체 복원',command=lambda:self.do_apply(True)).pack(side='left',padx=8)
        ttk.Button(buttons,text='v1.4 백업 복원',command=self.do_restore).pack(side='left')
    def show(self,text):
        self.info.configure(state='normal');self.info.delete('1.0','end');self.info.insert('1.0',text);self.info.configure(state='disabled')
    def choose(self):
        from tkinter import filedialog,messagebox
        p=filedialog.askdirectory(title='OPENING.EXE가 있는 게임 폴더 선택')
        if not p:return
        try:self.project=Path(p);self.refresh()
        except Exception as e:messagebox.showerror(APP_NAME,str(e))
    def refresh(self):
        a=analyze(self.project);self.path.configure(text=str(a.root));self.show(json.dumps(analysis_dict(a),ensure_ascii=False,indent=2))
    def do_apply(self,all_pc98):
        from tkinter import messagebox
        if not self.project:return
        label='플로라 32픽셀 선행 이동과 사람/빨간 피를 함께 복원' if all_pc98 else '플로라 32픽셀 선행 이동을 적용'
        if not messagebox.askyesno(APP_NAME,label+'할까요?\n\nv1.3이 적용되어 있어도 자동으로 교체하며, 현재 OPENING.EXE를 v1.4 백업으로 보존합니다.'):return
        try:r=apply(self.project,all_pc98);self.refresh();messagebox.showinfo(APP_NAME,'적용했습니다.\n\n'+json.dumps(r,ensure_ascii=False,indent=2))
        except Exception as e:messagebox.showerror(APP_NAME,str(e))
    def do_restore(self):
        from tkinter import messagebox
        if not self.project:return
        if not messagebox.askyesno(APP_NAME,'OPENING.EXE.pc98_opening_v14.bak을 복원할까요?'):return
        try:r=restore(self.project);self.refresh();messagebox.showinfo(APP_NAME,'복원했습니다.\n\n'+json.dumps(r,ensure_ascii=False,indent=2))
        except Exception as e:messagebox.showerror(APP_NAME,str(e))
    def run(self):self.root.mainloop()


def main(argv=None):
    ap=argparse.ArgumentParser(description=APP_NAME);ap.add_argument('path',nargs='?',type=Path)
    ap.add_argument('--analyze',action='store_true');ap.add_argument('--apply-flora',action='store_true');ap.add_argument('--apply-all',action='store_true');ap.add_argument('--restore',action='store_true');ap.add_argument('--no-gui',action='store_true')
    args=ap.parse_args(argv)
    if args.analyze or args.apply_flora or args.apply_all or args.restore:
        if not args.path:ap.error('게임 폴더 또는 OPENING.EXE 경로가 필요합니다.')
        r=restore(args.path) if args.restore else apply(args.path,args.apply_all) if (args.apply_flora or args.apply_all) else analysis_dict(analyze(args.path))
        print(json.dumps(r,ensure_ascii=False,indent=2));return 0
    if args.no_gui:return 0
    GUI().run();return 0
if __name__=='__main__':raise SystemExit(main())
