#!/usr/bin/env python3
"""Dragon Slayer: The Legend of Heroes II Korean UI text patch v1.3.1.

Patches exact, reviewed string slots in ED2MAIN.EXE only.  No SCENA DLL is
modified.  The file is never resized and no byte outside the declared slots is
changed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

VERSION = "1.3.1"
SUPPORTED_SIZE = 1_848_336
BACKUP_SUFFIX = ".ui_text_patch.bak"
REPORT_NAME = "ED2_UI_TEXT_PATCH_REPORT.json"


def cp(text: str) -> bytes:
    return text.encode("cp949")


def fixed(text: str, byte_length: int, *, newline: bool = False) -> bytes:
    """Encode and space-pad to an exact byte length.

    For strings ending in LF, padding is inserted before LF so the line control
    stays at the original final byte.
    """
    raw = cp(text)
    if len(raw) > byte_length:
        raise ValueError(f"문구가 슬롯보다 깁니다: {text!r} ({len(raw)}>{byte_length})")
    if newline:
        if not raw.endswith(b"\n"):
            raise ValueError("newline=True인데 LF로 끝나지 않습니다.")
        return raw[:-1] + b" " * (byte_length - len(raw)) + b"\n"
    return raw + b" " * (byte_length - len(raw))


@dataclass(frozen=True)
class Slot:
    offset: int
    original: bytes
    desired: bytes
    purpose: str
    group: str

    def __post_init__(self) -> None:
        if len(self.original) != len(self.desired):
            raise ValueError(f"슬롯 길이 불일치: {self.purpose}")


# Core requested labels.
CORE_SLOTS = (
    Slot(0x149D52, cp("남다  "), cp("남음  "), "설정 화면 EP 표시", "core"),
    Slot(0x14B0FC, cp("남다 "), cp("남음 "), "상태 화면 다음 레벨 경험치", "core"),
    Slot(0x14B2FE, cp(" 버린다"), cp(" 버리기"), "필드 메뉴 명령", "core"),
)

# Every occurrence below means spell/magic.  Five are labels, seven are system
# UI messages.  Story dialogue in SCENA DLLs is outside this patch.
MAGIC_LABEL_SLOTS = (
    Slot(0x149AA5, cp("주문"), cp("마법"), "전투 명령 메뉴", "magic_label"),
    Slot(0x149DB7, cp("주문"), cp("마법"), "자동 전투 설정: 공격 마법", "magic_label"),
    Slot(0x149DC1, cp("주문"), cp("마법"), "자동 회복 설정: 회복 마법", "magic_label"),
    Slot(0x14B0B9, cp("주문"), cp("마법"), "상태 화면: 마법능력", "magic_label"),
    Slot(0x14B2ED, cp("주문"), cp("마법"), "필드 메뉴 명령", "magic_label"),
)

MAGIC_SYSTEM_SLOTS = (
    Slot(0x14A9E1, cp("주문"), cp("마법"), "레벨업 능력 상승 메시지", "magic_system"),
    Slot(0x14AC3D, cp("주문"), cp("마법"), "전체 마법 봉인 메시지", "magic_system"),
    Slot(0x14AC7B, cp("주문"), cp("마법"), "개별 마법 봉인 메시지", "magic_system"),
    Slot(0x14ACBA, cp("주문"), cp("마법"), "마법 반사 메시지", "magic_system"),
    Slot(0x14B170, cp("주문"), cp("마법"), "마법 학습 대상 선택", "magic_system"),
    Slot(0x14B1A7, cp("주문"), cp("마법"), "마법 습득 메시지", "magic_system"),
    Slot(0x14B1FC, cp("주문"), cp("마법"), "마법 봉인 상태 메시지", "magic_system"),
)

# Reviewed UI wording.  Only unambiguous typos, spacing errors, and inconsistent
# command-label forms are included.  Every replacement fits the original slot.
WORDING_SLOTS = (
    Slot(0x1499C4, cp("전투의 직전으로"), fixed("전투 직전으로", 15), "패배 후 선택지", "wording"),
    Slot(0x1499D4, cp("모험을 계속한다"), fixed("모험 계속하기", 15), "패배 후 선택지", "wording"),
    Slot(0x1499E5, cp("하지만 이이상은 가질수가 없습니다  "), fixed("하지만 더 이상 가질 수 없습니다", 35), "소지 한도 안내", "wording"),
    Slot(0x149A09, cp("어떤것을 버리겠습니까? "), fixed("무엇을 버리겠습니까?", 23), "버릴 물건 선택", "wording"),
    Slot(0x149A49, cp(" POINT획득  "), fixed(" POINT 획득", 12), "전투 보상 표시", "wording"),
    Slot(0x149A56, cp(" Gold 얻었습니다  "), cp(" Gold를 얻었습니다"), "전투 보상 표시", "wording"),
    Slot(0x149B42, cp("도망친다"), cp("도망가기"), "전투 설정 명령", "wording"),
    Slot(0x149CA8, cp("세이브를 중지 하겠습니다  "), fixed("세이브를 중지하겠습니다", 26), "저장 오류 안내", "wording"),
    Slot(0x149D23, cp("메세지"), cp("메시지"), "설정 메뉴 맞춤법", "wording"),
    Slot(0x149D34, cp("펑션표시"), cp("기능표시"), "설정 메뉴 용어", "wording"),
    Slot(0x149DD1, cp("전원의 설정을"), cp("모두의 설정을"), "자동 전투 일괄 설정", "wording"),
    Slot(0x149DED, cp("쓴다  "), cp("사용함"), "자동 전투 설정", "wording"),
    Slot(0x149DF4, cp("안쓴다"), cp("미사용"), "자동 전투 설정", "wording"),
    Slot(0x149E09, cp("세이브 데이타를 삭제해도 좋습니까?"), cp("세이브 데이터를 삭제해도 좋습니까?"), "저장 데이터 삭제 확인", "wording"),
    Slot(0x14A055, cp("주십시요"), cp("주십시오"), "디스크 오류 안내 1", "wording"),
    Slot(0x14A06E, cp("주십시요"), cp("주십시오"), "디스크 오류 안내 2", "wording"),
    Slot(0x14A0A9, cp("주십시요"), cp("주십시오"), "디스크 삽입 안내", "wording"),
    Slot(0x14ABDA, cp("빼았았다.\n"), cp("빼앗았다.\n"), "HP 흡수 메시지", "wording"),
    Slot(0x14ACFA, cp("최근에 하던 곳 부터 시작하기"), fixed("최근에 하던 곳부터 시작하기", 28), "시작 메뉴 띄어쓰기", "wording"),
    Slot(0x14B103, cp("기절해있다 "), fixed("기절", 11), "상태 표시: 기절", "wording"),
    Slot(0x14B216, cp("아무 것도 일어나지 않았다 \n"), fixed("아무것도 일어나지 않았다\n", 27, newline=True), "효과 없음 메시지", "wording"),
    Slot(0x14B261, cp("에게는 듣지않았다 \n"), cp("에게는 듣지 않았다\n"), "효과 없음 메시지", "wording"),
)

ALL_SLOTS = CORE_SLOTS + MAGIC_LABEL_SLOTS + MAGIC_SYSTEM_SLOTS + WORDING_SLOTS

# 상태 표시의 `반`/`수`는 문자열이 아니라 4바이트 상태 테이블과
# 고정 3바이트 복사 루틴으로 출력된다. 두 글자 상태명을 지원하기
# 위해 같은 NE 세그먼트의 미사용 0 영역에 확장 루틴을 두고 원래
# 루틴에서 near jump한다. 파일/세그먼트 크기와 relocation은 바뀌지 않는다.
STATUS_ROUTINE_OFFSET = 0x15E306
STATUS_CAVE_OFFSET = 0x155700
STATUS_ROUTINE_ORIGINAL = bytes.fromhex(
    "AC 84 C4 75 06 83 C6 03 E2 F6 CB 87 FA A4 A5 87 FA CB"
)
STATUS_ROUTINE_PATCHED = bytes.fromhex(
    "E9 F7 73 90 90 90 90 90 90 90 90 90 90 90 90 90 90 90"
)
STATUS_CAVE_CODE = bytes.fromhex(
    "AC 84 E0 75 06 83 C6 03 E2 F6 CB "
    "3C 40 74 0B 3C 20 74 17 87 D7 A4 A5 87 D7 CB "
    "87 D7 8A 04 AA B8 B9 DD AB B8 BB E7 AB 87 D7 CB "
    "87 D7 8A 04 AA B8 B9 E6 AB B8 BE EE AB 87 D7 CB"
)
STATUS_CAVE_ORIGINAL = b"\x00" * len(STATUS_CAVE_CODE)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def resolve_exe(path: Path) -> Path:
    path = path.expanduser().resolve()
    exe = path / "ED2MAIN.EXE" if path.is_dir() else path
    if not exe.is_file() or exe.name.upper() != "ED2MAIN.EXE":
        raise FileNotFoundError(f"ED2MAIN.EXE를 찾을 수 없습니다: {exe}")
    return exe


def validate_ne(data: bytes) -> None:
    if len(data) != SUPPORTED_SIZE:
        raise ValueError(f"지원하지 않는 파일 크기입니다: {len(data):,} bytes")
    if data[:2] != b"MZ":
        raise ValueError("MZ 실행 파일이 아닙니다.")
    ne_off = struct.unpack_from("<I", data, 0x3C)[0]
    if ne_off + 2 > len(data) or data[ne_off:ne_off + 2] != b"NE":
        raise ValueError("NE 헤더를 찾을 수 없습니다.")


def selected_slots(labels_only: bool, no_wording: bool) -> tuple[Slot, ...]:
    slots = CORE_SLOTS + MAGIC_LABEL_SLOTS
    if not labels_only:
        slots += MAGIC_SYSTEM_SLOTS
    if not no_wording:
        slots += WORDING_SLOTS
    return slots


def accepted_values(slot: Slot) -> tuple[bytes, ...]:
    # Original and desired are both valid input states, making reapplication and
    # migration from older patch versions safe.
    values = [slot.original, slot.desired]
    if slot.offset == 0x14B103:
        values.append(cp("기절해 있다"))  # v1.2.0
        values.append(cp("기절 해있다"))  # spacing variant seen in some installs
    return tuple(dict.fromkeys(values))


def inspect_status_patch(data: bytes) -> dict[str, str]:
    routine = data[STATUS_ROUTINE_OFFSET:STATUS_ROUTINE_OFFSET + len(STATUS_ROUTINE_ORIGINAL)]
    cave = data[STATUS_CAVE_OFFSET:STATUS_CAVE_OFFSET + len(STATUS_CAVE_CODE)]
    if routine not in (STATUS_ROUTINE_ORIGINAL, STATUS_ROUTINE_PATCHED):
        raise ValueError(f"상태 출력 루틴이 예상과 다릅니다: {routine.hex(' ')}")
    if cave not in (STATUS_CAVE_ORIGINAL, STATUS_CAVE_CODE):
        raise ValueError("상태 출력 확장 영역이 예상과 다릅니다.")
    if routine == STATUS_ROUTINE_PATCHED and cave != STATUS_CAVE_CODE:
        raise ValueError("상태 출력 점프는 적용됐지만 확장 코드가 없습니다.")
    return {
        "routine": "patched" if routine == STATUS_ROUTINE_PATCHED else "original",
        "cave": "patched" if cave == STATUS_CAVE_CODE else "empty",
    }


def inspect(data: bytes) -> list[dict[str, object]]:
    validate_ne(data)
    inspect_status_patch(data)
    rows: list[dict[str, object]] = []
    for slot in ALL_SLOTS:
        current = data[slot.offset:slot.offset + len(slot.original)]
        if current not in accepted_values(slot):
            raise ValueError(
                f"0x{slot.offset:X} 문구가 예상과 다릅니다: "
                f"{current.hex(' ')} ({slot.purpose})"
            )
        rows.append({
            "offset": slot.offset,
            "group": slot.group,
            "purpose": slot.purpose,
            "current": current.decode("cp949"),
            "original": slot.original.decode("cp949"),
            "desired": slot.desired.decode("cp949"),
            "length": len(slot.original),
        })
    return rows


def atomic_write(path: Path, data: bytes) -> None:
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise


def build_target(data: bytes, labels_only: bool, no_wording: bool) -> tuple[bytes, list[dict[str, object]]]:
    selected = {slot.offset: slot for slot in selected_slots(labels_only, no_wording)}
    buf = bytearray(data)
    changes: list[dict[str, object]] = []

    # Selected slots go to desired state.  Unselected magic-system slots are
    # normalized back to 주문 so --labels-only repairs the old broad patch.
    for slot in ALL_SLOTS:
        if slot.offset in selected:
            wanted = slot.desired
        elif slot.group == "magic_system":
            wanted = slot.original
        else:
            continue
        current = bytes(buf[slot.offset:slot.offset + len(slot.original)])
        if current != wanted:
            buf[slot.offset:slot.offset + len(wanted)] = wanted
            changes.append({
                "offset": slot.offset,
                "group": slot.group,
                "purpose": slot.purpose,
                "before": current.decode("cp949"),
                "after": wanted.decode("cp949"),
                "byte_length": len(wanted),
            })
    # Always enable the expanded two-character battle-status labels.
    routine = bytes(buf[STATUS_ROUTINE_OFFSET:STATUS_ROUTINE_OFFSET + len(STATUS_ROUTINE_ORIGINAL)])
    cave = bytes(buf[STATUS_CAVE_OFFSET:STATUS_CAVE_OFFSET + len(STATUS_CAVE_CODE)])
    if routine != STATUS_ROUTINE_PATCHED or cave != STATUS_CAVE_CODE:
        buf[STATUS_CAVE_OFFSET:STATUS_CAVE_OFFSET + len(STATUS_CAVE_CODE)] = STATUS_CAVE_CODE
        buf[STATUS_ROUTINE_OFFSET:STATUS_ROUTINE_OFFSET + len(STATUS_ROUTINE_PATCHED)] = STATUS_ROUTINE_PATCHED
        changes.extend([
            {
                "offset": STATUS_ROUTINE_OFFSET, "group": "battle_status",
                "purpose": "상태 수→방어, 반→반사 출력 확장",
                "before": "고정 한 글자 출력", "after": "두 글자 상태 출력",
                "byte_length": len(STATUS_ROUTINE_PATCHED),
            },
            {
                "offset": STATUS_CAVE_OFFSET, "group": "battle_status",
                "purpose": "방어/반사 전용 출력 코드",
                "before": "미사용 00 영역", "after": "상태 출력 확장 코드",
                "byte_length": len(STATUS_CAVE_CODE),
            },
        ])
    return bytes(buf), changes


def patch(exe: Path, *, check_only: bool, labels_only: bool, no_wording: bool) -> int:
    before = exe.read_bytes()
    inspect(before)
    target, changes = build_target(before, labels_only, no_wording)

    mode = "레이블 5곳만" if labels_only else "마법 관련 UI 12곳 전체"
    wording = "제외" if no_wording else f"포함({len(WORDING_SLOTS)}곳)"
    print(f"대상: {exe}")
    print(f"모드: {mode}, UI 문장 교정 {wording}")
    print(f"변경 필요: {len(changes)}곳")

    if check_only:
        for row in changes:
            print(f"  0x{row['offset']:X}: {row['before']!r} -> {row['after']!r} ({row['purpose']})")
        return 0
    if not changes:
        print("이미 요청한 패치 상태입니다.")
        return 0

    backup = exe.with_name(exe.name + BACKUP_SUFFIX)
    if not backup.exists():
        shutil.copy2(exe, backup)
        print(f"백업 생성: {backup.name}")

    if len(target) != len(before):
        raise RuntimeError("패치 후 파일 크기가 달라졌습니다.")

    allowed: set[int] = set()
    for row in changes:
        off = int(row["offset"])
        allowed.update(range(off, off + int(row["byte_length"])))
    actual = {i for i, (a, b) in enumerate(zip(before, target)) if a != b}
    if not actual.issubset(allowed):
        raise RuntimeError("선언된 문구 슬롯 밖의 바이트가 변경되었습니다.")

    # Reparse all slots before committing.
    inspect(target)
    atomic_write(exe, target)
    reread = exe.read_bytes()
    if reread != target:
        raise RuntimeError("저장 후 바이트 재검증에 실패했습니다.")

    report = {
        "patch_version": VERSION,
        "target": str(exe),
        "backup": str(backup),
        "mode": {
            "labels_only": labels_only,
            "magic_scope": 5 if labels_only else 12,
            "wording_fixes": 0 if no_wording else len(WORDING_SLOTS),
            "battle_status_labels": {"0x20": "방어", "0x40": "반사"},
        },
        "size_before": len(before),
        "size_after": len(target),
        "sha256_before": sha256(before),
        "sha256_after": sha256(target),
        "changes": changes,
        "validation": {
            "mz_ne_valid": True,
            "file_size_unchanged": len(before) == len(target),
            "changes_limited_to_declared_slots": actual.issubset(allowed),
            "saved_bytes_match": reread == target,
        },
    }
    report_path = exe.parent / REPORT_NAME
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print("패치 완료:")
    for row in changes:
        print(f"  0x{row['offset']:X}: {row['before']!r} -> {row['after']!r} ({row['purpose']})")
    print(f"보고서: {report_path.name}")
    return 0


def restore(exe: Path) -> int:
    backup = exe.with_name(exe.name + BACKUP_SUFFIX)
    if not backup.is_file():
        print(f"백업을 찾을 수 없습니다: {backup}", file=sys.stderr)
        return 2
    data = backup.read_bytes()
    inspect(data)
    atomic_write(exe, data)
    if exe.read_bytes() != data:
        raise RuntimeError("복원 후 재검증에 실패했습니다.")
    print(f"복원 완료: {exe}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="영웅전설 2 한국판 UI 문구 정밀 패치")
    ap.add_argument("path", nargs="?", default=".", help="게임 폴더 또는 ED2MAIN.EXE")
    ap.add_argument(
        "--labels-only", action="store_true",
        help="주문→마법은 메뉴·설정·상태 레이블 5곳만 적용하고 시스템 문장 7곳은 주문으로 유지",
    )
    ap.add_argument("--no-wording", action="store_true", help="추가 UI 문장 교정을 적용하지 않음")
    action = ap.add_mutually_exclusive_group()
    action.add_argument("--check", action="store_true", help="검사만 수행")
    action.add_argument("--restore", action="store_true", help="이 패치 적용 전 파일로 복원")
    args = ap.parse_args()
    try:
        exe = resolve_exe(Path(args.path))
        if args.restore:
            return restore(exe)
        return patch(
            exe,
            check_only=args.check,
            labels_only=args.labels_only,
            no_wording=args.no_wording,
        )
    except Exception as exc:
        print(f"오류: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
