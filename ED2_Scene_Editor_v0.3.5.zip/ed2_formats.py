#!/usr/bin/env python3
"""Shared ED2 map/scene formats.

Only Python standard library is used.  The code deliberately limits writes to
structures that can be parsed and round-tripped from the original Korean DOS
release.
"""
from __future__ import annotations

import json
import os
import shutil
import struct
import tempfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

MAP_W = 32
MAP_H = 32
MAP_CELLS = MAP_W * MAP_H
ARCHIVE_RECORDS = 40
ARCHIVE_HEADER = 80
GRAPHIC_TILE_COUNT = 128
GRAPHIC_TILE_STRIDE = 160
GRAPHIC_COLOR_BYTES = 128
GRAPHIC_MASK_BYTES = 32
POINTER_SET_COUNT = 45
POINTER_ENTRIES = 128
POINTER_SET_STRIDE = POINTER_ENTRIES * 4


class FormatError(Exception):
    pass


def u16(data: bytes, off: int) -> int:
    return struct.unpack_from("<H", data, off)[0]


def u32(data: bytes, off: int) -> int:
    return struct.unpack_from("<I", data, off)[0]


def backup_once(path: Path) -> Path:
    backup = path.with_name(path.name + ".bak")
    if not backup.exists():
        shutil.copy2(path, backup)
    return backup


def atomic_write(path: Path, data: bytes) -> None:
    backup_once(path)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


class _BzhInput:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0

    def read8(self) -> int:
        if self.pos >= len(self.data):
            raise FormatError("Unexpected end of BZH stream")
        result = self.data[self.pos]
        self.pos += 1
        return result

    def read16(self) -> int:
        return self.read8() | (self.read8() << 8)


class _BzhWriter:
    def __init__(self):
        self.output = bytearray([0])
        self.control_pos = 0
        self.control_width = 8
        self.control_value = 0
        self.bit_index = 0

    def _flush(self) -> None:
        self.output[self.control_pos] = self.control_value & 0xFF
        if self.control_width == 16:
            self.output[self.control_pos + 1] = (self.control_value >> 8) & 0xFF

    def _new_word(self) -> None:
        self.control_pos = len(self.output)
        self.output.extend(b"\0\0")
        self.control_width = 16
        self.control_value = 0
        self.bit_index = 0

    def bit(self, value: int) -> None:
        if self.bit_index >= self.control_width:
            self._flush()
            self._new_word()
        if value:
            self.control_value |= 1 << self.bit_index
        self.bit_index += 1

    def byte(self, value: int) -> None:
        self.output.append(value & 0xFF)

    def finish(self) -> bytes:
        self._flush()
        return bytes(self.output)


def bzh_decompress(data: bytes) -> bytes:
    if len(data) < 4:
        raise FormatError("BZH file is too small")
    declared = data[0] | data[1] << 8 | data[2] << 16
    if declared != len(data) - 1:
        raise FormatError(f"BZH size mismatch: header={declared}, file={len(data)}")
    source = _BzhInput(data[3:])
    bitstream = source.read8()
    bits_left = 8
    output = bytearray()

    def bit() -> int:
        nonlocal bitstream, bits_left
        if bits_left == 0:
            bitstream = source.read16()
            bits_left = 16
        result = bitstream & 1
        bitstream >>= 1
        bits_left -= 1
        return result

    while source.pos < len(source.data):
        if bit() == 0:
            output.append(source.read8())
            continue
        extended = bit()
        high = 0
        if extended:
            for weight in (16, 8, 4, 2, 1):
                if bit():
                    high += weight
        distance = source.read8() + (high << 8)
        if extended and distance == 0:
            return bytes(output)
        if extended and distance == 1:
            long_count = bit()
            amount = 0
            for weight in (8, 4, 2, 1):
                if bit():
                    amount += weight
            if long_count:
                amount = (amount << 8) + source.read8()
            amount += 14
            output.extend([source.read8()] * amount)
            continue
        run = 2
        if bit() == 0:
            run += 1
            if bit() == 0:
                run += 1
                if bit() == 0:
                    run += 1
                    if bit() == 0:
                        if bit() == 0:
                            run = source.read8() + 14
                        else:
                            run += 1
                            for weight in (4, 2, 1):
                                if bit():
                                    run += weight
        if distance <= 0 or distance > len(output):
            raise FormatError(f"Invalid BZH distance {distance} at output {len(output)}")
        for _ in range(run):
            output.append(output[-distance])
    raise FormatError("BZH end marker missing")


def bzh_compress_literal(data: bytes) -> bytes:
    writer = _BzhWriter()
    for value in data:
        writer.bit(0)
        writer.byte(value)
    writer.bit(1)
    writer.bit(1)
    for _ in range(5):
        writer.bit(0)
    writer.byte(0)
    payload = writer.finish()
    declared = len(payload) + 2
    if declared > 0xFFFFFF:
        raise FormatError("BZH output exceeds 24-bit size field")
    return bytes((declared & 255, declared >> 8 & 255, declared >> 16 & 255)) + payload


def inner_rle_decode(data: bytes, max_output: int = 65535) -> tuple[bytes, int, bool]:
    out = bytearray()
    pos = 0
    while pos < len(data):
        control = data[pos]
        pos += 1
        if control == 0:
            return bytes(out), pos, True
        count = control & 0x7F
        if count == 0:
            return bytes(out), pos, False
        if control & 0x80:
            if pos >= len(data):
                return bytes(out), pos, False
            out.extend([data[pos]] * count)
            pos += 1
        else:
            if pos + count > len(data):
                return bytes(out), pos, False
            out.extend(data[pos:pos + count])
            pos += count
        if len(out) > max_output:
            return bytes(out), pos, False
    return bytes(out), pos, False


def inner_rle_encode(data: bytes) -> bytes:
    out = bytearray()
    literal = bytearray()

    def flush() -> None:
        nonlocal literal
        start = 0
        while start < len(literal):
            chunk = literal[start:start + 127]
            out.append(len(chunk))
            out.extend(chunk)
            start += len(chunk)
        literal = bytearray()

    pos = 0
    while pos < len(data):
        run = 1
        while pos + run < len(data) and data[pos + run] == data[pos] and run < 127:
            run += 1
        if run >= 3:
            flush()
            out.extend((0x80 | run, data[pos]))
            pos += run
        else:
            literal.append(data[pos])
            pos += 1
            if len(literal) == 127:
                flush()
    flush()
    out.append(0)
    return bytes(out)


@dataclass(frozen=True)
class NESegment:
    index: int
    file_offset: int
    length: int
    flags: int
    min_alloc: int


def parse_ne_segments(data: bytes) -> list[NESegment]:
    if len(data) < 0x40 or data[:2] != b"MZ":
        raise FormatError("Not an MZ executable")
    ne = u32(data, 0x3C)
    if ne + 0x40 > len(data) or data[ne:ne + 2] != b"NE":
        raise FormatError("Not a 16-bit NE module")
    count = u16(data, ne + 0x1C)
    table = ne + u16(data, ne + 0x22)
    shift = u16(data, ne + 0x32)
    result = []
    for i in range(count):
        sector, length, flags, alloc = struct.unpack_from("<HHHH", data, table + i * 8)
        result.append(NESegment(i + 1, sector << shift, 65536 if length == 0 else length, flags, alloc))
    return result


def parse_ne_export_ordinals(data: bytes) -> tuple[dict[int, tuple[int, int]], dict[int, str]]:
    ne = u32(data, 0x3C)
    entry = ne + u16(data, ne + 0x04)
    end = entry + u16(data, ne + 0x06)
    ordinal = 1
    entries: dict[int, tuple[int, int]] = {}
    pos = entry
    while pos < end:
        count, kind = data[pos], data[pos + 1]
        pos += 2
        if count == 0:
            break
        if kind == 0:
            ordinal += count
        elif kind == 0xFF:
            for _ in range(count):
                entries[ordinal] = (data[pos + 3], u16(data, pos + 4))
                ordinal += 1
                pos += 6
        else:
            for _ in range(count):
                entries[ordinal] = (kind, u16(data, pos + 1))
                ordinal += 1
                pos += 3

    def names_at(offset: int, size: Optional[int] = None) -> dict[int, str]:
        out: dict[int, str] = {}
        pos2 = offset
        limit = len(data) if size is None else min(len(data), offset + size)
        while pos2 < limit:
            length = data[pos2]
            pos2 += 1
            if length == 0:
                break
            name = data[pos2:pos2 + length].decode("latin1")
            pos2 += length
            ord_value = u16(data, pos2)
            pos2 += 2
            out[ord_value] = name
        return out

    names = names_at(ne + u16(data, ne + 0x26))
    names.update(names_at(u32(data, ne + 0x2C), u16(data, ne + 0x20)))
    return entries, names



@dataclass(frozen=True)
class NERelocation:
    segment: int
    source_type: int
    flags: int
    source_offset: int
    module: str
    ordinal: Optional[int]
    imported_name: Optional[str]


def _ne_import_tables(data: bytes) -> tuple[list[str], int]:
    ne = u32(data, 0x3C)
    imported = ne + u16(data, ne + 0x2A)
    module_refs = ne + u16(data, ne + 0x28)
    count = u16(data, ne + 0x1E)
    modules: list[str] = []
    for index in range(count):
        offset = u16(data, module_refs + index * 2)
        pos = imported + offset
        if pos >= len(data):
            raise FormatError("NE import module table is truncated")
        length = data[pos]
        modules.append(data[pos + 1:pos + 1 + length].decode("latin1"))
    return modules, imported


def parse_ne_relocations(data: bytes) -> list[NERelocation]:
    modules, imported_base = _ne_import_tables(data)

    def import_name(offset: int) -> str:
        pos = imported_base + offset
        if pos >= len(data):
            raise FormatError("NE imported-name table is truncated")
        length = data[pos]
        return data[pos + 1:pos + 1 + length].decode("latin1")

    result: list[NERelocation] = []
    for segment in parse_ne_segments(data):
        if not (segment.flags & 0x0100):
            continue
        pos = segment.file_offset + segment.length
        if pos + 2 > len(data):
            raise FormatError(f"Segment {segment.index}: relocation count is truncated")
        count = u16(data, pos)
        pos += 2
        for _ in range(count):
            if pos + 8 > len(data):
                raise FormatError(f"Segment {segment.index}: relocation table is truncated")
            source_type, flags, source, target1, target2 = struct.unpack_from("<BBHHH", data, pos)
            pos += 8
            target_kind = flags & 3
            module = modules[target1 - 1] if 0 < target1 <= len(modules) else f"module#{target1}"
            ordinal = target2 if target_kind == 1 else None
            name = import_name(target2) if target_kind == 2 else None
            result.append(NERelocation(segment.index, source_type, flags, source, module, ordinal, name))
    return result


SCENE_TYPE_LETTERS = "CDEFGHMTV"

def scene_name_from_sin(sin_no: int) -> str:
    type_index = (sin_no >> 12) & 0xF
    letter = SCENE_TYPE_LETTERS[type_index] if type_index < len(SCENE_TYPE_LETTERS) else "?"
    return f"{letter}_{sin_no & 0x0FFF:03X}.DLL"


@dataclass(frozen=True)
class TransitionRecord:
    source_scene: str
    call_segment: int
    call_source_offset: int
    record_segment: int
    record_offset: int
    mp_pny: int
    mp_pnx: int
    map_number: int
    map_mask: int
    ptr_no: int
    sin_no: int
    destination_scene: str
    bc_no: int
    bgm_no: int
    floor_chr_no: int
    town_no: int
    chr_nos: tuple[int, int, int, int, int, int, int, int]
    raw: bytes

    @property
    def map_kind(self) -> str:
        return "large" if self.destination_scene.startswith("F_") else "standard"

    @property
    def map_key(self) -> str:
        return f"{self.map_kind}:{self.map_number:03d}"

    @property
    def record_file_description(self) -> str:
        return f"seg {self.record_segment}:0x{self.record_offset:04X}"


TRANSITION_FIELD_OFFSETS = {
    "mp_pny": (3, 1),
    "mp_pnx": (4, 1),
    "map_number": (5, 1),
    "map_mask": (6, 1),
    "ptr_no": (11, 1),
    "sin_no": (12, 2),
    "bc_no": (15, 1),
    "bgm_no": (16, 1),
    "floor_chr_no": (17, 1),
    "town_no": (18, 1),
    "chr_no0": (26, 1),
    "chr_no1": (27, 1),
    "chr_no2": (28, 1),
    "chr_no3": (29, 1),
    "chr_no4": (30, 1),
    "chr_no5": (31, 1),
    "chr_no6": (32, 1),
    "chr_no7": (33, 1),
}


def extract_scene_transitions(
    path: Path, exe_ordinal_names: dict[int, str], data: Optional[bytes] = None,
) -> list[TransitionRecord]:
    data = path.read_bytes() if data is None else data
    segments = parse_ne_segments(data)
    relocations = parse_ne_relocations(data)
    seen: set[tuple[int, int]] = set()
    result: list[TransitionRecord] = []
    for relocation in relocations:
        if relocation.module.upper() != "ED2MAIN" or relocation.ordinal is None:
            continue
        target_name = exe_ordinal_names.get(relocation.ordinal, "")
        if target_name not in {"ENTER_PROG", "ENTER_PROG2"}:
            continue
        if not 1 <= relocation.segment <= len(segments):
            continue
        segment = segments[relocation.segment - 1]
        block = data[segment.file_offset:segment.file_offset + segment.length]
        source = relocation.source_offset
        # Borland call sequence: BB <record offset>; far call ENTER_PROG/2.
        if source < 4 or source > len(block) or block[source - 4] != 0xBB:
            continue
        record_offset = u16(block, source - 3)
        key = (segment.index, record_offset)
        if key in seen or record_offset + 34 > len(block):
            continue
        raw = bytes(block[record_offset:record_offset + 34])
        sin_no = u16(raw, 12)
        type_index = (sin_no >> 12) & 0xF
        if type_index >= len(SCENE_TYPE_LETTERS):
            continue
        map_number = raw[5]
        destination = scene_name_from_sin(sin_no)
        # Field maps are M_000 records 0..39; other scene classes use M_001..003.
        if destination.startswith("F_") and map_number > 39:
            continue
        if not destination.startswith("F_") and map_number > 119:
            continue
        seen.add(key)
        result.append(TransitionRecord(
            source_scene=path.name,
            call_segment=relocation.segment,
            call_source_offset=source,
            record_segment=segment.index,
            record_offset=record_offset,
            mp_pny=raw[3], mp_pnx=raw[4], map_number=map_number, map_mask=raw[6],
            ptr_no=raw[11], sin_no=sin_no, destination_scene=destination,
            bc_no=raw[15], bgm_no=raw[16], floor_chr_no=raw[17], town_no=raw[18],
            chr_nos=tuple(raw[26:34]), raw=raw,
        ))
    return sorted(result, key=lambda item: (item.record_segment, item.record_offset))

def parse_ne_exports(data: bytes) -> dict[str, tuple[int, int]]:
    entries, names = parse_ne_export_ordinals(data)
    return {name: entries[ordinal] for ordinal, name in names.items() if ordinal in entries}


def exe_scene_palette(exe_path: Path) -> list[tuple[int, int, int]]:
    """Return the base 16-color scene palette in normal RGB order.

    ST_SIN_PAL copies 48 bytes from ED2MAIN segment 85:0x39D8.  The
    table is already stored as R, G, B nibbles.  Earlier editor versions
    incorrectly swapped red and blue.
    """
    data = exe_path.read_bytes()
    segments = parse_ne_segments(data)
    if len(segments) < 85:
        raise FormatError("ED2MAIN.EXE does not contain expected segment 85")
    seg = segments[84]
    offset = seg.file_offset + 0x39D8
    raw = data[offset:offset + 48]
    if len(raw) != 48 or any(value > 15 for value in raw):
        raise FormatError("ED2 scene palette signature was not found")
    palette: list[tuple[int, int, int]] = []
    for index in range(0, 48, 3):
        red, green, blue = raw[index:index + 3]
        palette.append((red * 17, green * 17, blue * 17))
    return palette


@dataclass
class MapRecord:
    key: str
    map_id: int
    map_kind: str
    archive_number: int
    record_index: int
    archive_name: str
    tiles: Optional[bytearray]
    editable: bool
    description: str


class _ArchiveBase:
    def __init__(self, path: Path, archive_number: int):
        self.path = path
        self.archive_number = archive_number
        self.decompressed = bzh_decompress(path.read_bytes())
        if len(self.decompressed) < ARCHIVE_HEADER:
            raise FormatError(f"{path.name}: archive too small")
        self.offsets = list(struct.unpack_from("<40H", self.decompressed, 0))
        if self.offsets[0] != ARCHIVE_HEADER:
            raise FormatError(f"{path.name}: invalid first record offset")
        if any(a >= b for a, b in zip(self.offsets, self.offsets[1:])):
            raise FormatError(f"{path.name}: non-increasing record offsets")
        if self.offsets[-1] >= len(self.decompressed):
            raise FormatError(f"{path.name}: record offset outside archive")
        self.records = []
        for index, start in enumerate(self.offsets):
            end = self.offsets[index + 1] if index < 39 else len(self.decompressed)
            self.records.append(bytes(self.decompressed[start:end]))

    def rebuild(self, replacement_index: int, replacement: bytes) -> bytes:
        records = list(self.records)
        records[replacement_index] = replacement
        output = bytearray(b"\0" * ARCHIVE_HEADER)
        offsets = []
        for record in records:
            offsets.append(len(output))
            if offsets[-1] > 0xFFFF:
                raise FormatError("Archive record offset exceeds 16-bit range")
            output.extend(record)
        if len(output) > 0xFFFF:
            raise FormatError("Decompressed archive exceeds 65535 bytes")
        struct.pack_into("<40H", output, 0, *offsets)
        return bzh_compress_literal(bytes(output))


class StandardArchive(_ArchiveBase):
    def get(self, index: int, map_id: int) -> MapRecord:
        decoded, _used, terminated = inner_rle_decode(self.records[index], MAP_CELLS + 1)
        editable = terminated and len(decoded) == MAP_CELLS
        return MapRecord(
            key=f"standard:{map_id:03d}", map_id=map_id, map_kind="standard",
            archive_number=self.archive_number, record_index=index,
            archive_name=self.path.name, tiles=bytearray(decoded) if editable else None,
            editable=editable,
            description="표준 32×32 맵" if editable else "특수 레코드(읽기 전용)",
        )

    def replace(self, index: int, tiles: bytes) -> bytes:
        if len(tiles) != MAP_CELLS:
            raise ValueError("Map must contain 1024 tile codes")
        encoded = self.rebuild(index, inner_rle_encode(tiles))
        check = StandardArchive.from_bytes(encoded, self.path, self.archive_number)
        record = check.get(index, (self.archive_number - 1) * 40 + index)
        if not record.editable or bytes(record.tiles or b"") != tiles:
            raise FormatError("Standard map round-trip failed")
        return encoded

    @classmethod
    def from_bytes(cls, encoded: bytes, path: Path, number: int) -> "StandardArchive":
        obj = cls.__new__(cls)
        obj.path, obj.archive_number = path, number
        obj.decompressed = bzh_decompress(encoded)
        obj.offsets = list(struct.unpack_from("<40H", obj.decompressed, 0))
        obj.records = []
        for i, start in enumerate(obj.offsets):
            end = obj.offsets[i + 1] if i < 39 else len(obj.decompressed)
            obj.records.append(bytes(obj.decompressed[start:end]))
        return obj


@dataclass
class LargeParts:
    chunks: list[bytes]
    stream_lengths: list[int]
    trailing: bytes


def parse_large_record(raw: bytes) -> LargeParts:
    if len(raw) < 12:
        raise FormatError("Large map record is too short")
    starts = list(struct.unpack_from("<4H", raw, 0))
    if starts[0] != 8 or any(a >= b for a, b in zip(starts, starts[1:])) or starts[-1] >= len(raw):
        raise FormatError(f"Invalid large-map chunk offsets: {starts}")
    chunks: list[bytes] = []
    lengths: list[int] = []
    last_end = 0
    for i, start in enumerate(starts):
        limit = starts[i + 1] if i < 3 else len(raw)
        decoded, used, terminated = inner_rle_decode(raw[start:limit], 257)
        if not terminated or len(decoded) != 256:
            # The final stream may be followed by metadata; decode against the full tail.
            decoded, used, terminated = inner_rle_decode(raw[start:], 257)
        if not terminated or len(decoded) != 256:
            raise FormatError(f"Large-map chunk {i} does not decode to 16×16")
        chunks.append(decoded)
        lengths.append(used)
        last_end = start + used
    return LargeParts(chunks, lengths, raw[last_end:])


def join_quadrants(chunks: list[bytes]) -> bytes:
    if len(chunks) != 4 or any(len(chunk) != 256 for chunk in chunks):
        raise ValueError("Four 16×16 chunks are required")
    out = bytearray(MAP_CELLS)
    for y in range(32):
        for x in range(32):
            q = (2 if y >= 16 else 0) + (1 if x >= 16 else 0)
            out[y * 32 + x] = chunks[q][(y & 15) * 16 + (x & 15)]
    return bytes(out)


def split_quadrants(tiles: bytes) -> list[bytes]:
    if len(tiles) != MAP_CELLS:
        raise ValueError("Large map must contain 1024 tile codes")
    chunks = [bytearray(256) for _ in range(4)]
    for y in range(32):
        for x in range(32):
            q = (2 if y >= 16 else 0) + (1 if x >= 16 else 0)
            chunks[q][(y & 15) * 16 + (x & 15)] = tiles[y * 32 + x]
    return [bytes(chunk) for chunk in chunks]


class LargeArchive(_ArchiveBase):
    def get(self, index: int) -> MapRecord:
        try:
            parts = parse_large_record(self.records[index])
            tiles = bytearray(join_quadrants(parts.chunks))
            editable = True
            desc = "대형 필드 32×32 (16×16 청크 4개)"
        except Exception as exc:
            tiles = None
            editable = False
            desc = f"대형 필드 해석 실패: {exc}"
        return MapRecord(
            key=f"large:{index:03d}", map_id=index, map_kind="large",
            archive_number=0, record_index=index, archive_name=self.path.name,
            tiles=tiles, editable=editable, description=desc,
        )

    def replace(self, index: int, tiles: bytes) -> bytes:
        original = parse_large_record(self.records[index])
        chunks = split_quadrants(tiles)
        streams = [inner_rle_encode(chunk) for chunk in chunks]
        starts = []
        body = bytearray(b"\0" * 8)
        for stream in streams:
            starts.append(len(body))
            body.extend(stream)
        body.extend(original.trailing)
        if any(value > 0xFFFF for value in starts) or len(body) > 0xFFFF:
            raise FormatError("Large-map record exceeds 16-bit offsets")
        struct.pack_into("<4H", body, 0, *starts)
        encoded = self.rebuild(index, bytes(body))
        check = LargeArchive.from_bytes(encoded, self.path)
        record = check.get(index)
        if not record.editable or bytes(record.tiles or b"") != tiles:
            raise FormatError("Large map round-trip failed")
        return encoded

    @classmethod
    def from_bytes(cls, encoded: bytes, path: Path) -> "LargeArchive":
        obj = cls.__new__(cls)
        obj.path, obj.archive_number = path, 0
        obj.decompressed = bzh_decompress(encoded)
        obj.offsets = list(struct.unpack_from("<40H", obj.decompressed, 0))
        obj.records = []
        for i, start in enumerate(obj.offsets):
            end = obj.offsets[i + 1] if i < 39 else len(obj.decompressed)
            obj.records.append(bytes(obj.decompressed[start:end]))
        return obj


class TileSet:
    def __init__(self, path: Path, palette: list[tuple[int, int, int]]):
        self.path = path
        self.palette = palette
        data = bzh_decompress(path.read_bytes())
        expected = GRAPHIC_TILE_COUNT * GRAPHIC_TILE_STRIDE
        if len(data) != expected:
            raise FormatError(f"{path.name}: expected {expected} bytes, got {len(data)}")
        self.data = data
        self.tiles: list[list[int]] = []
        self.masks: list[bytes] = []
        for index in range(GRAPHIC_TILE_COUNT):
            start = index * GRAPHIC_TILE_STRIDE
            record = data[start:start + GRAPHIC_TILE_STRIDE]
            self.tiles.append(self._decode(record[:GRAPHIC_COLOR_BYTES]))
            self.masks.append(record[GRAPHIC_COLOR_BYTES:])

    @staticmethod
    def _decode(color_planes: bytes) -> list[int]:
        if len(color_planes) != GRAPHIC_COLOR_BYTES:
            raise FormatError("Tile color-plane record must be 128 bytes")
        pixels: list[int] = []
        # PC-98 color planes are B, R, G, I.  Their bit significance is the
        # native palette index order 1, 2, 4, 8.
        for y in range(16):
            for x in range(16):
                byte_index = y * 2 + x // 8
                bit = 7 - (x & 7)
                value = 0
                for plane in range(4):
                    value |= ((color_planes[plane * 32 + byte_index] >> bit) & 1) << plane
                pixels.append(value)
        return pixels

    def pixels_for_code(self, code: int) -> list[int]:
        # Map cells use seven graphic-index bits.  Bit 7 is an engine
        # attribute/collision flag and does not select another graphic tile.
        return self.tiles[code & 0x7F]

    def mask_for_code(self, code: int) -> bytes:
        return self.masks[code & 0x7F]


class PointerTable:
    """P_000.BZH metatile translation table.

    The 32x32 map records contain logical metatile codes.  PTR_NO selects
    one of 45 translation sets.  Each logical code expands to four graphic
    tile codes in top-left, top-right, bottom-left, bottom-right order.
    MAP_MASK controls which high-bit page is accepted by the original
    ED2MAIN conversion routine.
    """

    def __init__(self, path: Path):
        self.path = path
        self.data = bzh_decompress(path.read_bytes())
        expected = POINTER_SET_COUNT * POINTER_SET_STRIDE
        if len(self.data) != expected:
            raise FormatError(f"{path.name}: expected {expected} bytes, got {len(self.data)}")

    @staticmethod
    def effective_index(raw_code: int, map_mask: int) -> int:
        raw_code &= 0xFF
        map_mask &= 0xFF
        page = 1 if raw_code & 0x80 else 0
        if page == map_mask:
            return raw_code & 0x7F
        if map_mask == 0:
            return 126
        if map_mask == 1:
            return 127
        return (map_mask - 2) & 0x7F

    def graphic_codes(self, ptr_no: int, raw_code: int, map_mask: int = 0) -> tuple[int, int, int, int]:
        if not 0 <= ptr_no < POINTER_SET_COUNT:
            raise FormatError(f"PTR_NO must be 0..{POINTER_SET_COUNT - 1}, got {ptr_no}")
        index = self.effective_index(raw_code, map_mask)
        start = ptr_no * POINTER_SET_STRIDE + index * 4
        return tuple(self.data[start:start + 4])  # type: ignore[return-value]

    def set_bytes(self, ptr_no: int) -> bytes:
        if not 0 <= ptr_no < POINTER_SET_COUNT:
            raise FormatError(f"PTR_NO must be 0..{POINTER_SET_COUNT - 1}, got {ptr_no}")
        start = ptr_no * POINTER_SET_STRIDE
        return self.data[start:start + POINTER_SET_STRIDE]


class MapProject:
    def __init__(self, root: Path):
        self.root = root
        self.map_dir = root / "MAP"
        self.exe = root / "ED2MAIN.EXE"
        if not self.map_dir.is_dir() or not self.exe.is_file():
            raise FormatError("Select a folder containing ED2MAIN.EXE and MAP")
        self.palette = exe_scene_palette(self.exe)
        self.pointer_table = PointerTable(self.map_dir / "P_000.BZH")
        self.large = LargeArchive(self.map_dir / "M_000.BZH", 0)
        self.standard = {
            number: StandardArchive(self.map_dir / f"M_{number:03d}.BZH", number)
            for number in (1, 2, 3)
        }
        self.tile_paths = sorted(self.map_dir.glob("C_*.BZH"))
        self.tile_names = [path.name for path in self.tile_paths]
        self._tile_cache: dict[str, TileSet] = {}
        self.scene_dir = root / "SCENA"
        _entries, self.exe_ordinal_names = parse_ne_export_ordinals(self.exe.read_bytes())
        self.transitions: list[TransitionRecord] = []
        self.auto_map_tilesets: dict[str, str] = {}
        self.auto_map_scenes: dict[str, list[str]] = {}
        self.auto_map_profiles: dict[str, dict[int, int]] = {}
        self.transitions_by_map: dict[str, list[TransitionRecord]] = {}
        self._scan_scene_transitions()
        self.links_path = root / ".ed2_scene_links.json"
        self.links = self._load_links()

    def _scan_scene_transitions(self) -> None:
        if not self.scene_dir.is_dir():
            return
        counts: dict[str, Counter[int]] = defaultdict(Counter)
        scenes: dict[str, set[str]] = defaultdict(set)
        transitions: list[TransitionRecord] = []
        for path in sorted(self.scene_dir.glob("*.DLL")):
            try:
                found = extract_scene_transitions(path, self.exe_ordinal_names)
            except Exception:
                continue
            transitions.extend(found)
            for item in found:
                counts[item.map_key][item.bc_no] += 1
                scenes[item.map_key].add(item.destination_scene)
        self.transitions = transitions
        grouped: dict[str, list[TransitionRecord]] = defaultdict(list)
        for item in transitions:
            grouped[item.map_key].append(item)
        self.transitions_by_map = {
            key: sorted(value, key=lambda item: (
                item.source_scene, item.destination_scene, item.bc_no,
                item.bgm_no, item.record_segment, item.record_offset,
            ))
            for key, value in grouped.items()
        }
        for key, counter in counts.items():
            self.auto_map_profiles[key] = dict(sorted(counter.items()))
            for bc_no, _count in counter.most_common():
                name = f"C_{bc_no:03d}.BZH"
                if name in self.tile_names:
                    self.auto_map_tilesets[key] = name
                    break
        self.auto_map_scenes = {key: sorted(value) for key, value in scenes.items()}

    def _load_links(self) -> dict:
        if self.links_path.is_file():
            try:
                value = json.loads(self.links_path.read_text(encoding="utf-8"))
                if isinstance(value, dict):
                    value.setdefault("maps", {})
                    value.setdefault("scenes", {})
                    # v0.2 stored map-level tile overrides while the tile
                    # record stride and palette order were still wrong.
                    # Ignore only those obsolete map overrides; preserve the
                    # independently maintained scene profiles.
                    if int(value.get("format_version", 0) or 0) < 3:
                        cleaned = {}
                        for key, entry in value.get("maps", {}).items():
                            if isinstance(entry, dict):
                                rest = {k: v for k, v in entry.items() if k not in {"tileset", "context"}}
                                if rest:
                                    cleaned[key] = rest
                        value["maps"] = cleaned
                    value["format_version"] = 3
                    return value
            except Exception:
                pass
        return {"format_version": 3, "maps": {}, "scenes": {}}

    def save_links(self) -> None:
        self.links["format_version"] = 3
        self.links_path.write_text(json.dumps(self.links, ensure_ascii=False, indent=2), encoding="utf-8")

    def all_maps(self) -> list[MapRecord]:
        result = [self.large.get(i) for i in range(40)]
        for map_id in range(120):
            number = 1 + map_id // 40
            result.append(self.standard[number].get(map_id % 40, map_id))
        return result


    def transition_contexts(self, key: str) -> list[TransitionRecord]:
        return list(self.transitions_by_map.get(key, []))

    @staticmethod
    def transition_context_id(item: TransitionRecord) -> str:
        return (f"{item.source_scene}|{item.record_segment}:{item.record_offset:04X}|"
                f"{item.destination_scene}|{item.bc_no}|{item.ptr_no}|{item.map_mask}")

    @staticmethod
    def transition_context_label(item: TransitionRecord) -> str:
        return (f"{item.source_scene} → {item.destination_scene} | "
                f"BC {item.bc_no:03d} | PTR {item.ptr_no:02d} | MASK {item.map_mask:02d} | BGM {item.bgm_no:03d} | "
                f"진입 {item.mp_pny},{item.mp_pnx} | {item.record_file_description}")

    def remembered_context(self, key: str) -> Optional[TransitionRecord]:
        contexts = self.transition_contexts(key)
        if not contexts:
            return None
        wanted = self.links.get("maps", {}).get(key, {}).get("context")
        if isinstance(wanted, str):
            for item in contexts:
                if self.transition_context_id(item) == wanted:
                    return item
        return contexts[0]

    def remember_context(self, key: str, item: TransitionRecord) -> None:
        self.links.setdefault("maps", {}).setdefault(key, {})["context"] = self.transition_context_id(item)
        self.save_links()

    def tileset(self, name: str) -> TileSet:
        if name not in self.tile_names:
            raise FormatError(f"Tileset not found: {name}")
        if name not in self._tile_cache:
            self._tile_cache[name] = TileSet(self.map_dir / name, self.palette)
        return self._tile_cache[name]

    def remembered_tileset(self, key: str) -> str:
        value = self.links.get("maps", {}).get(key, {}).get("tileset")
        if value in self.tile_names:
            return value
        context = self.remembered_context(key)
        if context is not None:
            candidate = f"C_{context.bc_no:03d}.BZH"
            if candidate in self.tile_names:
                return candidate
        automatic = self.auto_map_tilesets.get(key)
        if automatic in self.tile_names:
            return automatic
        return self.tile_names[0]

    def tileset_source(self, key: str) -> str:
        value = self.links.get("maps", {}).get(key, {}).get("tileset")
        if value in self.tile_names:
            return "사용자 지정"
        context = self.remembered_context(key)
        if context is not None:
            profiles = self.auto_map_profiles.get(key, {})
            detail = ", ".join(f"BC {bc}: {count}회" for bc, count in sorted(profiles.items()))
            return ("선택된 실제 씬 전환: " + self.transition_context_label(context)
                    + (f" / 전체 후보 {detail}" if detail else ""))
        return "기본값(씬 전환 연결 없음)"

    def remember_tileset(self, key: str, name: str) -> None:
        self.links.setdefault("maps", {}).setdefault(key, {})["tileset"] = name
        self.save_links()

    def clear_tileset_override(self, key: str) -> None:
        maps = self.links.setdefault("maps", {})
        if key in maps and "tileset" in maps[key]:
            del maps[key]["tileset"]
            if not maps[key]:
                del maps[key]
            self.save_links()

    def scenes_for_map(self, key: str) -> list[str]:
        names = set(self.auto_map_scenes.get(key, []))
        names.update(name for name, value in self.links.get("scenes", {}).items() if value.get("map_key") == key)
        return sorted(names)

    def save_map(self, record: MapRecord, tiles: bytes) -> None:
        if record.map_kind == "large":
            encoded = self.large.replace(record.record_index, tiles)
            atomic_write(self.large.path, encoded)
            self.large = LargeArchive(self.large.path, 0)
        else:
            archive = self.standard[record.archive_number]
            encoded = archive.replace(record.record_index, tiles)
            atomic_write(archive.path, encoded)
            self.standard[record.archive_number] = StandardArchive(archive.path, record.archive_number)

    def restore(self, record: MapRecord) -> None:
        path = self.map_dir / record.archive_name
        backup = path.with_name(path.name + ".bak")
        if not backup.is_file():
            raise FileNotFoundError(f"Backup not found: {backup.name}")
        shutil.copy2(backup, path)
        if record.map_kind == "large":
            self.large = LargeArchive(path, 0)
        else:
            self.standard[record.archive_number] = StandardArchive(path, record.archive_number)

    def validate(self) -> dict:
        errors: list[str] = []
        warnings: list[str] = []
        large_ok = 0
        standard_ok = 0
        special = 0
        for record in self.all_maps():
            if record.editable:
                if record.map_kind == "large":
                    large_ok += 1
                else:
                    standard_ok += 1
                encoded = inner_rle_encode(bytes(record.tiles or b"")[:256])
                decoded, _used, term = inner_rle_decode(encoded)
                if not term or decoded != bytes(record.tiles or b"")[:256]:
                    errors.append(f"{record.key}: RLE round-trip failed")
            else:
                special += 1
        for name in self.tile_names:
            try:
                self.tileset(name)
            except Exception as exc:
                errors.append(f"{name}: {exc}")
        if special:
            warnings.append(f"{special} special standard-map records remain read-only")
        unresolved = sorted({item.bc_no for item in self.transitions if f"C_{item.bc_no:03d}.BZH" not in self.tile_names})
        if unresolved:
            warnings.append("Scene transitions reference missing tilesets: " + ", ".join(map(str, unresolved)))
        return {
            "ok": not errors,
            "large_maps": large_ok,
            "standard_maps": standard_ok,
            "special_records": special,
            "tilesets": len(self.tile_names),
            "pointer_sets": POINTER_SET_COUNT,
            "scene_transitions": len(self.transitions),
            "auto_linked_maps": len(self.auto_map_tilesets),
            "palette": self.palette,
            "errors": errors,
            "warnings": warnings,
        }
