# ED2 Scene Editor v0.3.5

영웅전설 2 DOS판 `SCENA/*.DLL` 독립 편집기입니다.

## 기능

- 원본 DLL 파일명 표시 및 검색
- 씬 전환, 맵, BC, BGM, 진입 좌표 편집
- 문자열 및 대사 CSV 내보내기·가져오기
- 사용자 알고리즘 슬롯
- 누락된 `ALGO_00` 생성
- `.bak` 백업과 전체 구조 검사

## 실행

```bat
python ed2_scene_editor.py
```
