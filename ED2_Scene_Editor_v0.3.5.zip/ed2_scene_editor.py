#!/usr/bin/env python3
"""ED2 Scene Editor v0.3.5.

Standalone, relocation-aware editor for Korean DOS ED2 SCENA/*.DLL files.
It supports verified transition/settings edits, fixed-capacity CP949 strings,
dialogue CSV round-trips, and custom machine-code algorithm slots placed in
validated NE code-segment padding.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import shutil
import struct
import tempfile
import tkinter as tk
from dataclasses import dataclass
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk
from typing import Optional

from ed2_formats import (
    FormatError, NESegment, TransitionRecord, TRANSITION_FIELD_OFFSETS,
    atomic_write, extract_scene_transitions, parse_ne_export_ordinals,
    parse_ne_exports, parse_ne_segments, scene_name_from_sin, u16, u32,
)
from ed2_algo_export import create_missing_algo00_export

APP_NAME = "ED2 Scene Editor"
VERSION = "0.3.5"

SAFE_VARIABLES = {
    "BGM_NO", "FLOOR_CHR_NO", "TOWN_NO", "MP_PNX", "MP_PNY",
    "CHR_NO0", "CHR_NO1", "CHR_NO2", "CHR_NO3",
    "CHR_NO4", "CHR_NO5", "CHR_NO6", "CHR_NO7",
}
DISPLAY_VARIABLES = SAFE_VARIABLES | {
    "MP_NUMBER", "MP_NUM", "MP_NMY", "BC_NO", "SIN_NO", "MAP_MASK", "PTR_NO",
    "MP_NMX", "CUR_SCENARIO", "FLOOR_CHR_NO", "TOWN_NO",
}


@dataclass(frozen=True)
class Relocation:
    segment: int
    source_type: int
    flags: int
    source_offset: int
    module: str
    ordinal: Optional[int]
    imported_name: Optional[str]


@dataclass
class Assignment:
    variable: str
    value: int
    size: int
    segment: int
    source_offset: int
    patch_file_offset: int
    opcode: str
    editable: bool


@dataclass(frozen=True)
class StringEntry:
    segment: int
    offset: int
    file_offset: int
    capacity: int
    text: str
    raw: bytes
    kind: str = "문자열"
    call_segment: Optional[int] = None
    call_offset: Optional[int] = None
    message_pointer: Optional[int] = None

    @property
    def signature(self) -> str:
        return hashlib.sha1(self.raw).hexdigest()[:16]


@dataclass(frozen=True)
class CustomAlgorithm:
    name: str
    segment: int
    offset: int
    size: int
    code_hex: str
    description: str = ""
    enabled: bool = True


@dataclass
class SceneModule:
    path: Path
    data: bytes
    segments: list[NESegment]
    exports: dict[str, tuple[int, int]]
    relocations: list[Relocation]
    assignments: list[Assignment]
    references: dict[str, int]
    strings: list[StringEntry]
    dialogues: list[StringEntry]
    transitions: list[TransitionRecord]


def _import_tables(data: bytes) -> tuple[list[str], int]:
    ne = u32(data, 0x3C)
    imported = ne + u16(data, ne + 0x2A)
    module_refs = ne + u16(data, ne + 0x28)
    count = u16(data, ne + 0x1E)
    modules = []
    for index in range(count):
        offset = u16(data, module_refs + index * 2)
        pos = imported + offset
        length = data[pos]
        modules.append(data[pos + 1:pos + 1 + length].decode("latin1"))
    return modules, imported


def parse_relocations(data: bytes) -> list[Relocation]:
    modules, imported_base = _import_tables(data)

    def imported_name(offset: int) -> str:
        pos = imported_base + offset
        length = data[pos]
        return data[pos + 1:pos + 1 + length].decode("latin1")

    result = []
    for segment in parse_ne_segments(data):
        if not (segment.flags & 0x0100):
            continue
        pos = segment.file_offset + segment.length
        if pos + 2 > len(data):
            raise FormatError(f"Segment {segment.index}: relocation count is truncated")
        count = u16(data, pos)
        pos += 2
        for _ in range(count):
            if pos + 8 > len(data):
                raise FormatError(f"Segment {segment.index}: relocation table is truncated")
            source_type, flags, source, target1, target2 = struct.unpack_from("<BBHHH", data, pos)
            pos += 8
            target_kind = flags & 3
            module = modules[target1 - 1] if 0 < target1 <= len(modules) else f"module#{target1}"
            ordinal = target2 if target_kind == 1 else None
            name = imported_name(target2) if target_kind == 2 else None
            result.append(Relocation(segment.index, source_type, flags, source, module, ordinal, name))
    return result


def _valid_cp949_pair(first: int, second: int) -> bool:
    if not (0x81 <= first <= 0xFE):
        return False
    try:
        bytes((first, second)).decode("cp949")
        return True
    except UnicodeDecodeError:
        return False


def extract_string_entries(data: bytes, segments: list[NESegment], minimum: int = 2) -> list[StringEntry]:
    result: list[StringEntry] = []
    for segment in segments:
        block = data[segment.file_offset:segment.file_offset + segment.length]
        pos = 0
        while pos < len(block):
            start = pos
            raw = bytearray()
            while pos < len(block):
                value = block[pos]
                if 0x20 <= value <= 0x7E or value == 0x09:
                    raw.append(value)
                    pos += 1
                    continue
                if pos + 1 < len(block) and _valid_cp949_pair(value, block[pos + 1]):
                    raw.extend(block[pos:pos + 2])
                    pos += 2
                    continue
                break
            if len(raw) >= minimum:
                try:
                    text = bytes(raw).decode("cp949")
                except UnicodeDecodeError:
                    text = ""
                if text and any(ch.isprintable() and not ch.isspace() for ch in text):
                    result.append(StringEntry(
                        segment=segment.index,
                        offset=start,
                        file_offset=segment.file_offset + start,
                        capacity=len(raw),
                        text=text,
                        raw=bytes(raw),
                    ))
            pos = max(pos + 1, start + 1)
    return result


DIALOGUE_CALLS = {"DISP_MESS", "DISP_MESS_LOW", "COPY_MESS", "COPY_MESS2"}

_GARBLED_DIALOGUE_SYLLABLES = set(
    "릱릦먮릨먻흫딊듗듓픲먇듑줸빷힑뗉곲롔렳쓿컋쒼쵈큅떾쥡윕픱핅햱뗻곀겿"
)
_DIALOGUE_ALLOWED_ASCII = set(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 "
    ".,!?…~^-_()[]:;\"'/+%"
)


def is_probable_dialogue_text(text: str) -> bool:
    value = text.strip()
    value = re.sub(r"[一-龥]{1,2}$", "", value).rstrip()
    if not value:
        return False
    hangul = [ch for ch in value if "가" <= ch <= "힣"]
    if len(hangul) < 2:
        return False
    if any("一" <= ch <= "龥" for ch in value):
        return False
    if any(ch in _GARBLED_DIALOGUE_SYLLABLES for ch in value):
        return False
    for ch in value:
        if ch in "\t\r\n":
            continue
        if "가" <= ch <= "힣" or ch in _DIALOGUE_ALLOWED_ASCII:
            continue
        if ch in "　！？（）［］「」『』・":
            continue
        return False
    compact = [ch for ch in value if not ch.isspace()]
    informative = sum(
        1 for ch in compact
        if "가" <= ch <= "힣" or (ch.isascii() and ch.isalnum()) or ch == "^"
    )
    if informative / max(1, len(compact)) < 0.35 and "Gold" not in value:
        return False
    if len(value) <= 3 and " " not in value:
        endings = (
            "다", "요", "죠", "네", "군", "야", "냐", "까", "라", "자",
            "어", "아", "워", "해", "래", "지", "게", "음", "응", "예",
            "님", "왕", "성", "장", "절", "탑",
        )
        if not value.endswith(endings) and not any(ch in value for ch in ".!?…~"):
            return False
    return True


def split_dialogue_payload(entry: StringEntry) -> tuple[str, int, bytes]:
    """Split visible CP949 text from trailing bytes misdetected as text.

    Some ED2 scene message streams place F2/F6 control opcodes immediately
    after text.  When the following byte also forms a valid CP949 pair, the
    generic scanner decodes the two command bytes as a CJK ideograph.  Those
    bytes are executable/message control data and must never be overwritten.
    """
    visible = entry.text
    protected = b""
    while visible:
        ch = visible[-1]
        encoded = ch.encode("cp949")
        is_cjk = "\u4e00" <= ch <= "\u9fff"
        is_known_garble = ch in _GARBLED_DIALOGUE_SYLLABLES
        previous = visible[-2] if len(visible) >= 2 else ""
        code_like_pair = (
            len(encoded) == 2
            and encoded[0] in range(0xF0, 0xF7)
            and (previous in " .!?…~" or is_cjk or is_known_garble)
        )
        if not (is_cjk or is_known_garble or code_like_pair):
            break
        visible = visible[:-1]
        protected = encoded + protected
    editable = len(visible.encode("cp949"))
    if editable + len(protected) != entry.capacity:
        # The scanner raw bytes are authoritative.  Refuse to trim if the
        # decoded character accounting does not exactly match the raw span.
        return entry.text, entry.capacity, b""
    return visible, editable, protected


def mark_dialogue_entries(
    entries: list[StringEntry], data: bytes, segments: list[NESegment],
    relocations: list[Relocation], exe_ordinal_names: dict[int, str],
) -> tuple[list[StringEntry], list[StringEntry]]:
    refs: list[tuple[int, int, int]] = []
    for relocation in relocations:
        if relocation.module.upper() != "ED2MAIN" or relocation.ordinal is None:
            continue
        if exe_ordinal_names.get(relocation.ordinal, "") not in DIALOGUE_CALLS:
            continue
        if not 1 <= relocation.segment <= len(segments):
            continue
        segment = segments[relocation.segment - 1]
        block = data[segment.file_offset:segment.file_offset + segment.length]
        source = relocation.source_offset
        pointer = None
        # Borland scene code normally emits MOV SI,imm16 immediately before
        # a far call to DISP_MESS/DISP_MESS_LOW.  Accept other 16-bit pointer
        # registers as a conservative fallback.
        for back in range(4, 18):
            op = source - back
            if op < 0 or op + 3 > len(block):
                continue
            if block[op] in (0xBE, 0xBF, 0xBB, 0xBA):
                candidate = u16(block, op + 1)
                if candidate < len(block):
                    pointer = candidate
                    break
        if pointer is not None:
            refs.append((relocation.segment, source, pointer))

    ranges: list[tuple[int, int, int, int]] = []
    by_segment: dict[int, list[tuple[int, int]]] = {}
    for segment, call, pointer in refs:
        by_segment.setdefault(segment, []).append((pointer, call))
    for segment_index, values in by_segment.items():
        segment = segments[segment_index - 1]
        block = data[segment.file_offset:segment.file_offset + segment.length]
        ordered = sorted(set(values))
        for index, (pointer, call) in enumerate(ordered):
            end = ordered[index + 1][0] if index + 1 < len(ordered) else min(len(block), pointer + 8192)
            zero_run = block.find(b"\x00" * 8, pointer + 1, end)
            if zero_run >= 0:
                end = zero_run
            ranges.append((segment_index, pointer, end, call))

    updated: list[StringEntry] = []
    dialogues: list[StringEntry] = []
    for entry in entries:
        matches = [item for item in ranges if item[0] == entry.segment and item[1] <= entry.offset < item[2]]
        if matches and is_probable_dialogue_text(entry.text):
            segment, pointer, _end, call = max(matches, key=lambda item: item[1])
            marked = StringEntry(
                segment=entry.segment, offset=entry.offset,
                file_offset=entry.file_offset, capacity=entry.capacity,
                text=entry.text, raw=entry.raw, kind="대사",
                call_segment=segment, call_offset=call,
                message_pointer=pointer,
            )
            updated.append(marked)
            dialogues.append(marked)
        else:
            updated.append(entry)
    return updated, dialogues


def load_scene(path: Path, exe_ordinal_names: dict[int, str]) -> SceneModule:
    data = path.read_bytes()
    segments = parse_ne_segments(data)
    exports = parse_ne_exports(data)
    relocations = parse_relocations(data)
    references: dict[str, int] = {}
    assignments: list[Assignment] = []
    for relocation in relocations:
        if relocation.module.upper() != "ED2MAIN" or relocation.ordinal is None:
            continue
        variable = exe_ordinal_names.get(relocation.ordinal, f"ordinal_{relocation.ordinal}")
        references[variable] = references.get(variable, 0) + 1
        if not 1 <= relocation.segment <= len(segments):
            continue
        segment = segments[relocation.segment - 1]
        source = relocation.source_offset
        block = data[segment.file_offset:segment.file_offset + segment.length]
        value = None
        size = 0
        patch = -1
        opcode = ""
        if source >= 2 and block[source - 2:source] == b"\xC6\x06" and source + 2 < len(block):
            value, size, patch, opcode = block[source + 2], 1, segment.file_offset + source + 2, "C6 06 imm8"
        elif source >= 2 and block[source - 2:source] == b"\xC7\x06" and source + 3 < len(block):
            value, size, patch, opcode = u16(block, source + 2), 2, segment.file_offset + source + 2, "C7 06 imm16"
        elif source >= 3 and block[source - 1] == 0xA2 and block[source - 3] == 0xB0:
            value, size, patch, opcode = block[source - 2], 1, segment.file_offset + source - 2, "B0 imm8 / A2"
        elif source >= 4 and block[source - 1] == 0xA3 and block[source - 4] == 0xB8:
            value, size, patch, opcode = u16(block, source - 3), 2, segment.file_offset + source - 3, "B8 imm16 / A3"
        if value is not None and variable in DISPLAY_VARIABLES:
            assignments.append(Assignment(
                variable, value, size, relocation.segment, source, patch, opcode,
                variable in SAFE_VARIABLES,
            ))
    transitions = extract_scene_transitions(path, exe_ordinal_names, data)
    # Scene text lives in NE data segments.  Scanning executable code as
    # CP949 produced hundreds of false strings made from instruction bytes.
    # Keep general string editing limited to data segments; dialogue marking
    # still follows verified ED2MAIN message-call relocations.
    text_segments = [segment for segment in segments if segment.flags & 0x0001]
    strings = extract_string_entries(data, text_segments)
    strings, dialogues = mark_dialogue_entries(
        strings, data, segments, relocations, exe_ordinal_names,
    )
    return SceneModule(path, data, segments, exports, relocations, assignments,
                       references, strings, dialogues, transitions)


class SceneProject:
    def __init__(self, root: Path):
        self.root = root
        self.exe = root / "ED2MAIN.EXE"
        self.scene_dir = root / "SCENA"
        self.map_dir = root / "MAP"
        if not self.exe.is_file() or not self.scene_dir.is_dir():
            raise FormatError("Select a folder containing ED2MAIN.EXE and SCENA")
        exe_data = self.exe.read_bytes()
        _entries, self.exe_ord_names = parse_ne_export_ordinals(exe_data)
        self.paths = sorted(self.scene_dir.glob("*.DLL"))
        self.tile_names = [path.name for path in sorted(self.map_dir.glob("C_*.BZH"))]
        self.links_path = root / ".ed2_scene_links.json"
        self.links = self._load_links()
        self.algorithms_path = root / ".ed2_scene_algorithms.json"
        self.algorithms = self._load_algorithms()

    def _load_links(self) -> dict:
        if self.links_path.is_file():
            try:
                result = json.loads(self.links_path.read_text(encoding="utf-8"))
                if isinstance(result, dict):
                    result.setdefault("maps", {})
                    result.setdefault("scenes", {})
                    return result
            except Exception:
                pass
        return {"maps": {}, "scenes": {}}

    def save_links(self) -> None:
        self.links_path.write_text(json.dumps(self.links, ensure_ascii=False, indent=2), encoding="utf-8")

    def _load_algorithms(self) -> dict:
        if self.algorithms_path.is_file():
            try:
                value = json.loads(self.algorithms_path.read_text(encoding="utf-8"))
                if isinstance(value, dict):
                    value.setdefault("version", 1)
                    value.setdefault("scenes", {})
                    value.setdefault("bindings", {})
                    return value
            except Exception:
                pass
        return {"version": 1, "scenes": {}, "bindings": {}}

    def save_algorithms(self) -> None:
        self.algorithms_path.write_text(
            json.dumps(self.algorithms, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def create_missing_algo00_export(self, scene: SceneModule) -> SceneModule:
        return create_missing_algo00_export(self, scene)

    def custom_algorithms(self, dll_name: str) -> list[CustomAlgorithm]:
        result = []
        for item in self.algorithms.get("scenes", {}).get(dll_name, []):
            try:
                result.append(CustomAlgorithm(
                    name=str(item["name"]), segment=int(item["segment"]),
                    offset=int(item["offset"]), size=int(item["size"]),
                    code_hex=str(item["code_hex"]),
                    description=str(item.get("description", "")),
                    enabled=bool(item.get("enabled", True)),
                ))
            except Exception:
                continue
        return result

    @staticmethod
    def _segment_table_length_offset(data: bytes, segment_index: int) -> int:
        ne = u32(data, 0x3C)
        count = u16(data, ne + 0x1C)
        if not 1 <= segment_index <= count:
            raise FormatError("Invalid NE segment index")
        table = ne + u16(data, ne + 0x22)
        return table + (segment_index - 1) * 8 + 2

    @staticmethod
    def _next_segment_offset(scene: SceneModule, segment: NESegment) -> int:
        candidates = [item.file_offset for item in scene.segments if item.file_offset > segment.file_offset]
        return min(candidates) if candidates else len(scene.data)

    def add_custom_algorithm(self, scene: SceneModule, name: str, code: bytes, description: str = "") -> SceneModule:
        name = name.strip()
        if not name:
            raise ValueError("알고리즘 이름이 비어 있습니다")
        if any(item.name == name for item in self.custom_algorithms(scene.path.name)):
            raise ValueError("같은 이름의 사용자 알고리즘이 이미 있습니다")
        if not code:
            raise ValueError("알고리즘 바이트가 비어 있습니다")
        if len(code) > 512:
            raise ValueError("사용자 알고리즘은 최대 512바이트입니다")
        if code[-1] not in (0xCB, 0xCA, 0xC3, 0xC2):
            code += b"\xCB"

        current = self.load(scene.path)
        algorithm_exports = [value for key, value in current.exports.items() if key.startswith("ALGO_")]
        segment_index = algorithm_exports[0][0] if algorithm_exports else min(3, len(current.segments))
        segment = current.segments[segment_index - 1]
        seg_end = segment.file_offset + segment.length
        relocation_size = 0
        if segment.flags & 0x0100:
            if seg_end + 2 > len(current.data):
                raise FormatError("재배치 테이블이 잘렸습니다")
            relocation_size = 2 + u16(current.data, seg_end) * 8
        next_offset = self._next_segment_offset(current, segment)
        available = next_offset - (seg_end + relocation_size)
        if segment.length + len(code) > 0xFFFF:
            raise FormatError("사용자 알고리즘을 추가하면 NE 세그먼트 길이가 16비트 범위를 넘습니다")
        if len(code) > available:
            raise FormatError(
                f"코드 세그먼트 패딩이 부족합니다: 필요 {len(code)}바이트, 사용 가능 {available}바이트"
            )
        # The relocation table is moved forward by len(code).  Refuse to
        # overwrite anything except alignment padding at its destination.
        padding = current.data[seg_end + relocation_size:
                               seg_end + relocation_size + len(code)]
        if len(padding) != len(code) or any(value not in (0x00, 0x90, 0xCC, 0xFF) for value in padding):
            raise FormatError("재배치 테이블 뒤 공간이 순수 패딩이 아니므로 알고리즘 삽입을 중단했습니다")

        original_size = len(current.data)
        data = bytearray(current.data)
        relocation = bytes(data[seg_end:seg_end + relocation_size])
        data[seg_end:seg_end + len(code)] = code
        if relocation_size:
            data[seg_end + len(code):seg_end + len(code) + relocation_size] = relocation
        length_pos = self._segment_table_length_offset(data, segment_index)
        struct.pack_into("<H", data, length_pos, segment.length + len(code))
        if len(data) != original_size:
            raise FormatError("알고리즘 삽입 중 DLL 파일 크기가 변경되었습니다")
        atomic_write(scene.path, bytes(data))

        entry = {
            "name": name, "segment": segment_index, "offset": segment.length,
            "size": len(code), "code_hex": code.hex(" "),
            "description": description, "enabled": True,
        }
        self.algorithms.setdefault("scenes", {}).setdefault(scene.path.name, []).append(entry)
        self.save_algorithms()
        check = self.load(scene.path)
        check_segment = check.segments[segment_index - 1]
        actual = check.data[check_segment.file_offset + segment.length:
                            check_segment.file_offset + segment.length + len(code)]
        if actual != code:
            raise FormatError("사용자 알고리즘 삽입 검증에 실패했습니다")
        return check

    def edit_custom_algorithm(self, scene: SceneModule, algorithm: CustomAlgorithm, code: bytes) -> SceneModule:
        if not code:
            raise ValueError("알고리즘 바이트가 비어 있습니다")
        if code[-1] not in (0xCB, 0xCA, 0xC3, 0xC2):
            code += b"\xCB"
        if len(code) > algorithm.size:
            raise ValueError(f"기존 예약 크기 {algorithm.size}바이트를 넘을 수 없습니다")
        current = self.load(scene.path)
        if not 1 <= algorithm.segment <= len(current.segments):
            raise FormatError("사용자 알고리즘 세그먼트가 유효하지 않습니다")
        segment = current.segments[algorithm.segment - 1]
        file_offset = segment.file_offset + algorithm.offset
        old = current.data[file_offset:file_offset + algorithm.size]
        if len(old) != algorithm.size:
            raise FormatError("사용자 알고리즘 슬롯이 잘렸습니다")
        padded = code + b"\x90" * (algorithm.size - len(code))
        data = bytearray(current.data)
        data[file_offset:file_offset + algorithm.size] = padded
        atomic_write(scene.path, bytes(data))
        for item in self.algorithms.get("scenes", {}).get(scene.path.name, []):
            if item.get("name") == algorithm.name:
                item["code_hex"] = padded.hex(" ")
                item["enabled"] = True
        self.save_algorithms()
        return self.load(scene.path)

    def disable_custom_algorithm(self, scene: SceneModule, algorithm: CustomAlgorithm) -> SceneModule:
        return self.edit_custom_algorithm(scene, algorithm, b"\xCB")

    def attach_export(self, scene: SceneModule, export_name: str, algorithm: CustomAlgorithm) -> SceneModule:
        current = self.load(scene.path)
        if export_name not in current.exports or not export_name.startswith("ALGO_"):
            raise ValueError("연결할 기존 ALGO_XX Export를 선택하세요")
        segment_index, export_offset = current.exports[export_name]
        if segment_index != algorithm.segment:
            raise FormatError("기존 ALGO와 사용자 알고리즘이 같은 세그먼트에 있지 않습니다")
        segment = current.segments[segment_index - 1]
        file_offset = segment.file_offset + export_offset
        original = bytes(current.data[file_offset:file_offset + 5])
        if len(original) != 5:
            raise FormatError("ALGO 엔트리 바이트가 잘렸습니다")
        relative = algorithm.offset - (export_offset + 4)
        if not -32768 <= relative <= 32767:
            raise FormatError("사용자 알고리즘이 near call 범위를 벗어났습니다")
        stub = b"\x0E\xE8" + struct.pack("<h", relative) + b"\xCB"
        bindings = self.algorithms.setdefault("bindings", {}).setdefault(scene.path.name, {})
        previous = bindings.get(export_name)
        if previous is None:
            bindings[export_name] = {
                "original_hex": original.hex(" "),
                "target": algorithm.name,
            }
        else:
            previous["target"] = algorithm.name
        data = bytearray(current.data)
        data[file_offset:file_offset + 5] = stub
        atomic_write(scene.path, bytes(data))
        self.save_algorithms()
        check = self.load(scene.path)
        check_segment = check.segments[segment_index - 1]
        if check.data[check_segment.file_offset + export_offset:
                      check_segment.file_offset + export_offset + 5] != stub:
            raise FormatError("ALGO 연결 검증에 실패했습니다")
        return check

    def restore_export_binding(self, scene: SceneModule, export_name: str) -> SceneModule:
        binding = self.algorithms.get("bindings", {}).get(scene.path.name, {}).get(export_name)
        if not binding:
            raise ValueError("저장된 원본 ALGO 연결 정보가 없습니다")
        current = self.load(scene.path)
        if export_name not in current.exports:
            raise FormatError("ALGO Export가 사라졌습니다")
        segment_index, export_offset = current.exports[export_name]
        original = bytes.fromhex(binding["original_hex"])
        if len(original) != 5:
            raise FormatError("저장된 원본 ALGO 바이트가 잘못되었습니다")
        segment = current.segments[segment_index - 1]
        data = bytearray(current.data)
        start = segment.file_offset + export_offset
        data[start:start + 5] = original
        atomic_write(scene.path, bytes(data))
        del self.algorithms["bindings"][scene.path.name][export_name]
        self.save_algorithms()
        return self.load(scene.path)

    def patch_string(self, scene: SceneModule, entry: StringEntry, text: str) -> SceneModule:
        current = self.load(scene.path)
        match = next((item for item in current.strings
                      if item.segment == entry.segment and item.offset == entry.offset), None)
        if match is None or match.raw != entry.raw:
            raise FormatError("문자열 원본 서명이 달라져 저장을 중단했습니다")
        _visible, editable, protected = split_dialogue_payload(match)
        encoded = text.encode("cp949")
        if len(encoded) > editable:
            raise ValueError(
                f"CP949 기준 {len(encoded)}바이트입니다. 안전하게 수정 가능한 최대 길이는 {editable}바이트입니다"
            )
        data = bytearray(current.data)
        replacement = encoded + b" " * (editable - len(encoded)) + protected
        data[match.file_offset:match.file_offset + match.capacity] = replacement
        atomic_write(scene.path, bytes(data))
        written = scene.path.read_bytes()[match.file_offset:match.file_offset + match.capacity]
        if written != replacement or written[editable:] != match.raw[editable:]:
            raise FormatError("문자열 또는 보호된 씬 제어 바이트 저장 검증에 실패했습니다")
        return self.load(scene.path)

    @staticmethod
    def _csv_fields() -> list[str]:
        return [
            "dll", "kind", "segment", "offset", "file_offset",
            "call_segment", "call_offset", "message_pointer",
            "capacity_bytes", "editable_bytes", "protected_suffix_hex",
            "signature", "source_text",
        ]

    def export_strings_csv(self, csv_path: Path, dialogues_only: bool = False, current: Optional[Path] = None) -> int:
        paths = [current] if current is not None else self.paths
        count = 0
        with csv_path.open("w", newline="", encoding="utf-8-sig") as fp:
            writer = csv.DictWriter(fp, fieldnames=self._csv_fields())
            writer.writeheader()
            for path in paths:
                scene = self.load(path)
                entries = scene.dialogues if dialogues_only else scene.strings
                for entry in entries:
                    visible, editable, protected = split_dialogue_payload(entry)
                    writer.writerow({
                        "dll": path.name, "kind": entry.kind,
                        "segment": entry.segment, "offset": f"0x{entry.offset:04X}",
                        "file_offset": f"0x{entry.file_offset:06X}",
                        "call_segment": entry.call_segment if entry.call_segment is not None else "",
                        "call_offset": f"0x{entry.call_offset:04X}" if entry.call_offset is not None else "",
                        "message_pointer": f"0x{entry.message_pointer:04X}" if entry.message_pointer is not None else "",
                        "capacity_bytes": entry.capacity,
                        "editable_bytes": editable,
                        "protected_suffix_hex": protected.hex().upper(),
                        "signature": entry.signature,
                        "source_text": visible,
                    })
                    count += 1
        return count

    def import_strings_csv(self, csv_path: Path, dialogues_only: bool = False) -> int:
        """Apply source_text while preserving adjacent scene control bytes.

        The entire CSV is preflighted before any DLL is written.  F2/F6
        command suffixes that happen to decode as CP949 are protected and
        remain byte-identical.
        """
        with csv_path.open("r", newline="", encoding="utf-8-sig") as fp:
            rows = list(csv.DictReader(fp))
        if rows and "source_text" not in rows[0]:
            raise FormatError("CSV에 source_text 열이 없습니다")
        grouped: dict[str, list[dict]] = {}
        for row in rows:
            dll_name = (row.get("dll") or "").strip()
            if dll_name:
                grouped.setdefault(dll_name, []).append(row)

        total_changed = 0
        write_plans: list[tuple[Path, SceneModule, bytes, list[tuple[int, int, int]]]] = []

        # Phase 1: validate and build every patched DLL in memory.
        for dll_name, items in grouped.items():
            path = self.scene_dir / dll_name
            if not path.is_file():
                raise FileNotFoundError(f"씬 DLL을 찾을 수 없습니다: {dll_name}")
            scene = self.load(path)
            original_data = scene.data
            data = bytearray(original_data)
            entries = scene.dialogues if dialogues_only else scene.strings
            lookup = {(item.segment, item.offset): item for item in entries}
            planned_ranges: list[tuple[int, int, int]] = []
            dll_changed = 0

            for row in items:
                segment = int(row["segment"], 0)
                offset = int(row["offset"], 0)
                entry = lookup.get((segment, offset))
                if entry is None:
                    raise FormatError(f"{dll_name} seg {segment}:0x{offset:04X} 문자열을 찾을 수 없습니다")
                if row.get("signature") and row["signature"] != entry.signature:
                    raise FormatError(f"{dll_name} seg {segment}:0x{offset:04X} 원문 서명이 다릅니다")

                visible, detected_editable, detected_suffix = split_dialogue_payload(entry)
                editable_text = (row.get("editable_bytes") or "").strip()
                editable = int(editable_text, 0) if editable_text else detected_editable
                if not 0 <= editable <= entry.capacity:
                    raise FormatError(f"{dll_name} seg {segment}:0x{offset:04X} editable_bytes가 잘못되었습니다")
                expected_suffix = entry.raw[editable:]
                suffix_hex = (row.get("protected_suffix_hex") or "").strip().replace(" ", "")
                if suffix_hex:
                    try:
                        declared_suffix = bytes.fromhex(suffix_hex)
                    except ValueError as exc:
                        raise FormatError(f"{dll_name} seg {segment}:0x{offset:04X} 보호 접미사 HEX가 잘못되었습니다") from exc
                    if declared_suffix != expected_suffix:
                        raise FormatError(f"{dll_name} seg {segment}:0x{offset:04X} 보호된 씬 제어 바이트가 원본과 다릅니다")
                elif detected_suffix and editable != detected_editable:
                    raise FormatError(f"{dll_name} seg {segment}:0x{offset:04X} 안전 경계가 일치하지 않습니다")

                replacement_text = row.get("source_text", "")
                if replacement_text == visible and editable == detected_editable:
                    continue
                encoded = replacement_text.encode("cp949")
                if len(encoded) > editable:
                    raise ValueError(
                        f"{dll_name} seg {segment}:0x{offset:04X}: 수정문 {len(encoded)}바이트 > 안전 한계 {editable}바이트"
                    )
                begin = entry.file_offset
                finish = begin + entry.capacity
                if any(begin < other_end and other_begin < finish
                       for other_begin, other_end, _ in planned_ranges):
                    raise FormatError(f"{dll_name} seg {segment}:0x{offset:04X} CSV 문자열 범위가 중복됩니다")
                planned_ranges.append((begin, finish, editable))
                replacement = encoded + b" " * (editable - len(encoded)) + expected_suffix
                data[begin:finish] = replacement
                dll_changed += 1
                total_changed += 1

            if dll_changed:
                if len(data) != len(original_data):
                    raise FormatError(f"{dll_name}: DLL 크기가 변경되었습니다")
                for begin, finish, editable in planned_ranges:
                    if bytes(data[begin + editable:finish]) != original_data[begin + editable:finish]:
                        raise FormatError(f"{dll_name}: 씬 제어 바이트 변경을 감지하여 적용을 중단했습니다")
                # Parse the in-memory candidate before committing.
                with tempfile.NamedTemporaryFile(prefix=dll_name + ".", suffix=".tmp", delete=False) as tmp:
                    tmp_path = Path(tmp.name)
                    tmp.write(data)
                try:
                    candidate = self.load(tmp_path)
                finally:
                    tmp_path.unlink(missing_ok=True)
                if candidate.exports != scene.exports or len(candidate.transitions) != len(scene.transitions):
                    raise FormatError(f"{dll_name}: 적용 후 Export/전환 구조가 달라집니다")
                write_plans.append((path, scene, bytes(data), planned_ranges))

        # Phase 2: commit only after the complete CSV passed preflight.
        for path, scene, patched_data, planned_ranges in write_plans:
            atomic_write(path, patched_data)
            check = self.load(path)
            if check.exports != scene.exports or len(check.transitions) != len(scene.transitions):
                raise FormatError(f"{path.name}: 저장 후 Export/전환 구조 검증에 실패했습니다")
            written = path.read_bytes()
            for begin, finish, editable in planned_ranges:
                if written[begin + editable:finish] != scene.data[begin + editable:finish]:
                    raise FormatError(f"{path.name}: 저장 후 보호된 씬 제어 바이트가 달라졌습니다")
        return total_changed


    def load(self, path: Path) -> SceneModule:
        return load_scene(path, self.exe_ord_names)

    def patch_assignment(self, scene: SceneModule, assignment: Assignment, value: int) -> SceneModule:
        if not assignment.editable:
            raise ValueError(f"{assignment.variable} is read-only")
        maximum = 255 if assignment.size == 1 else 65535
        if not 0 <= value <= maximum:
            raise ValueError(f"Value must be 0..{maximum}")
        current = self.load(scene.path)
        match = next((item for item in current.assignments
                      if item.variable == assignment.variable
                      and item.segment == assignment.segment
                      and item.source_offset == assignment.source_offset
                      and item.opcode == assignment.opcode), None)
        if not match or match.patch_file_offset != assignment.patch_file_offset:
            raise FormatError("Scene instruction signature changed; patch refused")
        data = bytearray(current.data)
        if match.size == 1:
            data[match.patch_file_offset] = value
        else:
            struct.pack_into("<H", data, match.patch_file_offset, value)
        atomic_write(scene.path, bytes(data))
        check = self.load(scene.path)
        verified = next((item for item in check.assignments
                         if item.variable == match.variable
                         and item.segment == match.segment
                         and item.source_offset == match.source_offset), None)
        if not verified or verified.value != value:
            raise FormatError("Scene patch verification failed")
        return check

    def patch_transition(self, scene: SceneModule, transition: TransitionRecord,
                         values: dict[str, int]) -> SceneModule:
        current = self.load(scene.path)
        match = next((item for item in current.transitions
                      if item.record_segment == transition.record_segment
                      and item.record_offset == transition.record_offset), None)
        if not match or match.raw != transition.raw:
            raise FormatError("Scene transition record signature changed; patch refused")
        if not 1 <= match.record_segment <= len(current.segments):
            raise FormatError("Transition record segment is invalid")
        normalized: dict[str, int] = {}
        for field, value in values.items():
            if field not in TRANSITION_FIELD_OFFSETS:
                raise ValueError(f"Unsupported transition field: {field}")
            offset, size = TRANSITION_FIELD_OFFSETS[field]
            maximum = 255 if size == 1 else 65535
            value = int(value)
            if not 0 <= value <= maximum:
                raise ValueError(f"{field} must be 0..{maximum}")
            normalized[field] = value
        new_sin = normalized.get("sin_no", match.sin_no)
        new_map = normalized.get("map_number", match.map_number)
        destination = scene_name_from_sin(new_sin)
        if destination.startswith("?_"):
            raise ValueError("SIN_NO scene type must be C/D/E/F/G/H/M/T/V")
        limit = 39 if destination.startswith("F_") else 119
        if new_map > limit:
            raise ValueError(f"{destination} uses {'large' if limit == 39 else 'standard'} maps; map must be 0..{limit}")
        data = bytearray(current.data)
        segment = current.segments[match.record_segment - 1]
        record_file_offset = segment.file_offset + match.record_offset
        if bytes(data[record_file_offset:record_file_offset + 34]) != match.raw:
            raise FormatError("Transition record bytes changed; patch refused")
        for field, value in normalized.items():
            offset, size = TRANSITION_FIELD_OFFSETS[field]
            if size == 1:
                data[record_file_offset + offset] = value
            else:
                struct.pack_into("<H", data, record_file_offset + offset, value)
        atomic_write(scene.path, bytes(data))
        check = self.load(scene.path)
        verified = next((item for item in check.transitions
                         if item.record_segment == match.record_segment
                         and item.record_offset == match.record_offset), None)
        if not verified:
            raise FormatError("Transition record disappeared after patch")
        for field, value in normalized.items():
            actual = verified.chr_nos[int(field[-1])] if field.startswith("chr_no") else getattr(verified, field)
            if actual != value:
                raise FormatError(f"Transition patch verification failed: {field}")
        return check

    def restore(self, path: Path) -> None:
        backup = path.with_name(path.name + ".bak")
        if not backup.is_file():
            raise FileNotFoundError(f"Backup not found: {backup.name}")
        shutil.copy2(backup, path)

    def scene_link(self, name: str) -> dict:
        return dict(self.links.get("scenes", {}).get(name, {}))

    def set_scene_link(self, name: str, map_kind: str, map_id: Optional[int], tileset: str, note: str) -> None:
        map_key = None if map_kind == "none" or map_id is None else f"{map_kind}:{map_id:03d}"
        value = {"map_key": map_key, "tileset": tileset or None, "note": note}
        self.links.setdefault("scenes", {})[name] = value
        if map_key and tileset:
            self.links.setdefault("maps", {}).setdefault(map_key, {})["tileset"] = tileset
        self.save_links()

    def validate(self) -> dict:
        errors = []
        assignment_count = 0
        export_count = 0
        transition_count = 0
        for path in self.paths:
            try:
                scene = self.load(path)
                assignment_count += len(scene.assignments)
                export_count += len(scene.exports)
                transition_count += len(scene.transitions)
            except Exception as exc:
                errors.append(f"{path.name}: {exc}")
        return {
            "ok": not errors,
            "scene_dlls": len(self.paths),
            "resolved_immediate_assignments": assignment_count,
            "exports": export_count,
            "scene_transitions": transition_count,
            "errors": errors,
        }


class Editor(tk.Tk):
    def __init__(self, initial_root: Optional[Path] = None):
        super().__init__()
        self.title(f"{APP_NAME} v{VERSION}")
        self.geometry("1480x900")
        self.minsize(1050, 700)
        self.project: Optional[SceneProject] = None
        self.scene: Optional[SceneModule] = None
        self.path_by_iid: dict[str, Path] = {}
        self.assignment_by_iid: dict[str, Assignment] = {}
        self.transition_by_iid: dict[str, TransitionRecord] = {}
        self.string_by_iid: dict[str, StringEntry] = {}
        self.custom_algorithm_by_iid: dict[str, CustomAlgorithm] = {}
        self.export_by_iid: dict[str, str] = {}
        self.transition_vars: dict[str, tk.StringVar] = {}
        self.search_var = tk.StringVar()
        self.scene_rows: list[tuple[Path, int, int, int, str]] = []
        self._build_ui()
        if initial_root:
            self.after(30, lambda: self.open_project(initial_root))

    @staticmethod
    def _tree(parent, columns):
        holder = ttk.Frame(parent)
        tree = ttk.Treeview(holder, columns=columns, show="headings", selectmode="browse")
        ybar = ttk.Scrollbar(holder, orient="vertical", command=tree.yview)
        xbar = ttk.Scrollbar(holder, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        tree.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        holder.rowconfigure(0, weight=1)
        holder.columnconfigure(0, weight=1)
        return holder, tree

    @staticmethod
    def _text(parent):
        holder = ttk.Frame(parent)
        text = tk.Text(holder, wrap="none", state="disabled")
        ybar = ttk.Scrollbar(holder, orient="vertical", command=text.yview)
        xbar = ttk.Scrollbar(holder, orient="horizontal", command=text.xview)
        text.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        text.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        holder.rowconfigure(0, weight=1)
        holder.columnconfigure(0, weight=1)
        return holder, text

    def _build_ui(self) -> None:
        top = ttk.Frame(self, padding=7)
        top.pack(fill="x")
        ttk.Button(top, text="게임 폴더 열기", command=self.choose_project).pack(side="left")
        ttk.Button(top, text="새로고침", command=self.reload_current).pack(side="left", padx=(6, 0))
        ttk.Button(top, text="DLL 백업 복원", command=self.restore_current).pack(side="left", padx=(6, 0))
        ttk.Button(top, text="전체 검사", command=self.validate_project).pack(side="left", padx=(18, 0))
        ttk.Label(top, text="DLL 파일명 검색").pack(side="left", padx=(18, 4))
        search_entry = ttk.Entry(top, textvariable=self.search_var, width=20)
        search_entry.pack(side="left")
        self.search_var.trace_add("write", lambda *_args: self._refresh_scene_tree())
        self.root_label = ttk.Label(top, text="ED2MAIN.EXE와 SCENA 폴더가 있는 게임 폴더를 선택하세요.")
        self.root_label.pack(side="left", padx=16)

        pane = ttk.Panedwindow(self, orient="horizontal")
        pane.pack(fill="both", expand=True, padx=7, pady=(0, 7))
        left = ttk.Frame(pane)
        pane.add(left, weight=2)
        holder, self.scene_tree = self._tree(left, ("file", "size", "exports", "settings", "transitions", "link"))
        holder.pack(fill="both", expand=True)
        for column, title, width in (("file", "DLL 파일명", 145), ("size", "크기", 90), ("exports", "Export", 80),
                                     ("settings", "확정 설정", 100), ("transitions", "전환", 70),
                                     ("link", "대표 목적지/맵/BC", 260)):
            self.scene_tree.heading(column, text=title)
            self.scene_tree.column(column, width=width, stretch=False)
        self.scene_tree.bind("<<TreeviewSelect>>", self._scene_selected)

        right = ttk.Frame(pane)
        pane.add(right, weight=6)
        notebook = ttk.Notebook(right)
        notebook.pack(fill="both", expand=True)

        transition_tab = ttk.Frame(notebook, padding=7)
        notebook.add(transition_tab, text="씬 전환/맵")
        transition_pane = ttk.Panedwindow(transition_tab, orient="horizontal")
        transition_pane.pack(fill="both", expand=True)
        transition_left = ttk.Frame(transition_pane)
        transition_pane.add(transition_left, weight=5)
        trans_holder, self.transition_tree = self._tree(
            transition_left,
            ("dll", "destination", "kind", "map", "bc", "ptr", "mask", "bgm", "position", "record"),
        )
        trans_holder.pack(fill="both", expand=True)
        for column, title, width in (
            ("dll", "원본 DLL", 130), ("destination", "목적지 씬", 130), ("kind", "맵 형식", 80),
            ("map", "맵", 55), ("bc", "BC", 55), ("ptr", "PTR", 55),
            ("mask", "MASK", 55), ("bgm", "BGM", 55),
            ("position", "좌표 Y,X", 90), ("record", "레코드", 120),
        ):
            self.transition_tree.heading(column, text=title)
            self.transition_tree.column(column, width=width, stretch=False)
        self.transition_tree.bind("<<TreeviewSelect>>", self._transition_selected)

        form_outer = ttk.Frame(transition_pane)
        transition_pane.add(form_outer, weight=3)
        form_canvas = tk.Canvas(form_outer, highlightthickness=0)
        form_y = ttk.Scrollbar(form_outer, orient="vertical", command=form_canvas.yview)
        form_x = ttk.Scrollbar(form_outer, orient="horizontal", command=form_canvas.xview)
        form_canvas.configure(yscrollcommand=form_y.set, xscrollcommand=form_x.set)
        form_canvas.grid(row=0, column=0, sticky="nsew")
        form_y.grid(row=0, column=1, sticky="ns")
        form_x.grid(row=1, column=0, sticky="ew")
        form_outer.rowconfigure(0, weight=1)
        form_outer.columnconfigure(0, weight=1)
        self.transition_form = ttk.Frame(form_canvas, padding=10)
        form_window = form_canvas.create_window((0, 0), window=self.transition_form, anchor="nw")
        self.transition_form.bind(
            "<Configure>",
            lambda _e: form_canvas.configure(scrollregion=form_canvas.bbox("all")),
        )
        form_canvas.bind(
            "<Configure>",
            lambda e: form_canvas.itemconfigure(form_window, width=max(430, e.width)),
        )
        self.transition_title = ttk.Label(self.transition_form, text="실제 ENTER_PROG 전환 레코드", font=("TkDefaultFont", 10, "bold"))
        self.transition_title.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 4))
        self.transition_file_label = ttk.Label(self.transition_form, text="원본 DLL 파일명: -")
        self.transition_file_label.grid(row=1, column=0, columnspan=2, sticky="w", pady=(0, 8))
        transition_fields = (
            ("sin_no", "목적지 SIN_NO (16진수 가능)"),
            ("map_number", "맵 번호"), ("bc_no", "BC 타일셋 번호"),
            ("ptr_no", "PTR_NO 메타타일 표"),
            ("bgm_no", "BGM 번호"), ("map_mask", "MAP_MASK"),
            ("floor_chr_no", "바닥 캐릭터"), ("town_no", "마을 번호"),
            ("mp_pny", "진입 Y"), ("mp_pnx", "진입 X"),
            ("chr_no0", "CHR_NO0"), ("chr_no1", "CHR_NO1"),
            ("chr_no2", "CHR_NO2"), ("chr_no3", "CHR_NO3"),
            ("chr_no4", "CHR_NO4"), ("chr_no5", "CHR_NO5"),
            ("chr_no6", "CHR_NO6"), ("chr_no7", "CHR_NO7"),
        )
        for row, (field, label) in enumerate(transition_fields, start=2):
            variable = tk.StringVar()
            self.transition_vars[field] = variable
            ttk.Label(self.transition_form, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=3)
            ttk.Entry(self.transition_form, textvariable=variable, width=24).grid(row=row, column=1, sticky="ew", pady=3)
        self.transition_dest_label = ttk.Label(self.transition_form, text="목적지: -", wraplength=400)
        final_row = 2 + len(transition_fields)
        self.transition_dest_label.grid(row=final_row, column=0, columnspan=2, sticky="w", pady=(8, 4))
        ttk.Button(self.transition_form, text="선택 전환 레코드 저장", command=self.save_transition).grid(
            row=final_row + 1, column=0, columnspan=2, sticky="ew", pady=(8, 0)
        )
        ttk.Label(
            self.transition_form,
            text="전환 레코드는 고정 길이 34바이트 안에서 수정합니다. 사용자 알고리즘은 별도 탭에서 검증된 코드 여유 공간에 추가합니다.",
            wraplength=410,
        ).grid(row=final_row + 2, column=0, columnspan=2, sticky="w", pady=(10, 0))
        self.transition_form.columnconfigure(1, weight=1)

        settings_tab = ttk.Frame(notebook, padding=7)
        notebook.add(settings_tab, text="씬 설정")
        settings_pane = ttk.Panedwindow(settings_tab, orient="horizontal")
        settings_pane.pack(fill="both", expand=True)
        assignments_left = ttk.Frame(settings_pane)
        settings_pane.add(assignments_left, weight=4)
        assign_holder, self.assign_tree = self._tree(assignments_left, ("value", "size", "segment", "offset", "opcode", "editable"))
        assign_holder.pack(fill="both", expand=True)
        for column, title, width in (("value", "값", 90), ("size", "크기", 60), ("segment", "세그먼트", 70), ("offset", "오프셋", 90), ("opcode", "명령", 130), ("editable", "수정", 70)):
            self.assign_tree.heading(column, text=title)
            self.assign_tree.column(column, width=width, stretch=False)
        self.assign_tree.bind("<Double-1>", lambda _e: self.edit_assignment())
        ttk.Button(assignments_left, text="선택 값 수정", command=self.edit_assignment).pack(anchor="e", pady=(6, 0))

        profile = ttk.LabelFrame(settings_pane, text="맵 에디터 연결 프로필", padding=10)
        settings_pane.add(profile, weight=2)
        self.map_kind = tk.StringVar(value="none")
        self.map_id = tk.StringVar()
        self.tileset = tk.StringVar()
        self.note = tk.StringVar()
        self.map_kind_box = ttk.Combobox(profile, values=("none", "large", "standard"), state="readonly", textvariable=self.map_kind)
        self.map_id_entry = ttk.Entry(profile, textvariable=self.map_id)
        self.tileset_box = ttk.Combobox(profile, state="readonly", textvariable=self.tileset)
        self.note_entry = ttk.Entry(profile, textvariable=self.note)
        for row, (label, widget) in enumerate((
            ("맵 형식", self.map_kind_box),
            ("맵 번호", self.map_id_entry),
            ("BC 타일셋", self.tileset_box),
            ("메모", self.note_entry),
        )):
            ttk.Label(profile, text=label).grid(row=row, column=0, sticky="w", pady=4)
            widget.grid(row=row, column=1, sticky="ew", pady=4)
        profile.columnconfigure(1, weight=1)
        ttk.Button(profile, text="연결 프로필 저장", command=self.save_profile).grid(row=4, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        ttk.Label(profile, text="이 프로필은 맵 미리보기 연결용이며, DLL 코드 자체를 변경하지 않습니다.", wraplength=300).grid(row=5, column=0, columnspan=2, sticky="w", pady=(10, 0))

        exports_tab = ttk.Frame(notebook, padding=7)
        notebook.add(exports_tab, text="Export/알고리즘")
        algorithm_tools = ttk.Frame(exports_tab)
        algorithm_tools.pack(fill="x", pady=(0, 6))
        ttk.Button(algorithm_tools, text="누락 ALGO_00 생성", command=self.create_algo00).pack(side="left")
        ttk.Button(algorithm_tools, text="사용자 알고리즘 추가", command=self.add_algorithm).pack(side="left", padx=(6, 0))
        ttk.Button(algorithm_tools, text="바이트 수정", command=self.edit_algorithm).pack(side="left", padx=(6, 0))
        ttk.Button(algorithm_tools, text="기존 ALGO에 연결", command=self.attach_algorithm).pack(side="left", padx=(6, 0))
        ttk.Button(algorithm_tools, text="ALGO 연결 복원", command=self.restore_algorithm_binding).pack(side="left", padx=(6, 0))
        ttk.Button(algorithm_tools, text="사용자 알고리즘 비활성화", command=self.disable_algorithm).pack(side="left", padx=(6, 0))
        export_holder, self.export_tree = self._tree(exports_tab, ("name", "segment", "offset", "size", "kind", "status"))
        export_holder.pack(fill="both", expand=True)
        for column, title, width in (
            ("name", "이름", 180), ("segment", "세그먼트", 80),
            ("offset", "오프셋", 90), ("size", "크기", 70),
            ("kind", "분류", 120), ("status", "상태/연결", 240),
        ):
            self.export_tree.heading(column, text=title)
            self.export_tree.column(column, width=width, stretch=(column == "status"))

        refs_tab = ttk.Frame(notebook, padding=7)
        notebook.add(refs_tab, text="엔진 참조")
        ref_holder, self.ref_tree = self._tree(refs_tab, ("count", "meaning"))
        ref_holder.pack(fill="both", expand=True)
        self.ref_tree.heading("count", text="참조 수")
        self.ref_tree.heading("meaning", text="상태")
        self.ref_tree.column("count", width=100, stretch=False)
        self.ref_tree.column("meaning", width=300, stretch=True)

        strings_tab = ttk.Frame(notebook, padding=7)
        notebook.add(strings_tab, text="문자열/대사")
        string_tools = ttk.Frame(strings_tab)
        string_tools.pack(fill="x", pady=(0, 6))
        ttk.Button(string_tools, text="선택 문자열 수정", command=self.edit_string).pack(side="left")
        ttk.Button(string_tools, text="현재 DLL 문자열 CSV", command=self.export_current_strings).pack(side="left", padx=(6, 0))
        ttk.Button(string_tools, text="문자열 CSV 적용", command=self.import_strings).pack(side="left", padx=(6, 0))
        ttk.Button(string_tools, text="전체 대사 CSV 추출", command=self.export_dialogues).pack(side="left", padx=(18, 0))
        ttk.Button(string_tools, text="대사 CSV 적용", command=self.import_dialogues).pack(side="left", padx=(6, 0))
        strings_holder, self.strings_tree = self._tree(
            strings_tab, ("kind", "segment", "offset", "capacity", "call", "text"),
        )
        strings_holder.pack(fill="both", expand=True)
        for column, title, width in (
            ("kind", "분류", 70), ("segment", "세그먼트", 70),
            ("offset", "오프셋", 90), ("capacity", "최대 바이트", 90),
            ("call", "대사 호출/포인터", 180), ("text", "문자열", 620),
        ):
            self.strings_tree.heading(column, text=title)
            self.strings_tree.column(column, width=width, stretch=(column == "text"))
        self.strings_tree.bind("<Double-1>", lambda _e: self.edit_string())

        raw_tab = ttk.Frame(notebook, padding=7)
        notebook.add(raw_tab, text="파일 정보")
        raw_holder, self.raw_text = self._text(raw_tab)
        raw_holder.pack(fill="both", expand=True)

        self.status = ttk.Label(self, text="준비", relief="sunken", anchor="w")
        self.status.pack(fill="x", side="bottom")

    def choose_project(self) -> None:
        folder = filedialog.askdirectory(title="영웅전설 2 게임 폴더 선택")
        if folder:
            self.open_project(Path(folder))

    def open_project(self, root: Path) -> None:
        try:
            self.project = SceneProject(root)
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        self.root_label.config(text=str(root))
        self.tileset_box.configure(values=[""] + self.project.tile_names)
        self.scene_rows = []
        for path in self.project.paths:
            try:
                scene = self.project.load(path)
                settings = len(scene.assignments)
                exports = len(scene.exports)
                transitions = len(scene.transitions)
                if scene.transitions:
                    first = scene.transitions[0]
                    description = f"{first.destination_scene} / {first.map_key} / BC {first.bc_no}"
                else:
                    description = "-"
            except Exception:
                settings, exports, transitions, description = -1, -1, -1, "오류"
            self.scene_rows.append((path, exports, settings, transitions, description))
        self._refresh_scene_tree()
        self.status.config(text=f"로드 완료: SCENA DLL {len(self.project.paths)}개")
        if self.scene_rows:
            first_path = self.scene_rows[0][0]
            first_iid = next(iter(self.path_by_iid), None)
            if first_iid is not None:
                self.scene_tree.selection_set(first_iid)
                self.scene_tree.see(first_iid)
            self.load_scene(first_path)

    def _refresh_scene_tree(self) -> None:
        if not hasattr(self, "scene_tree"):
            return
        query = self.search_var.get().strip().lower() if hasattr(self, "search_var") else ""
        selected_path = self.scene.path if self.scene is not None else None
        self.path_by_iid.clear()
        self.scene_tree.delete(*self.scene_tree.get_children())
        selected_iid = None
        visible_index = 0
        for path, exports, settings, transitions, description in self.scene_rows:
            if query and query not in path.name.lower():
                continue
            iid = str(visible_index)
            visible_index += 1
            self.path_by_iid[iid] = path
            self.scene_tree.insert(
                "", "end", iid=iid,
                values=(path.name, path.stat().st_size, exports, settings, transitions, description),
            )
            if selected_path == path:
                selected_iid = iid
        if selected_iid is not None:
            self.scene_tree.selection_set(selected_iid)
            self.scene_tree.see(selected_iid)

    def _scene_selected(self, _event=None) -> None:
        selected = self.scene_tree.selection()
        if selected and selected[0] in self.path_by_iid:
            self.load_scene(self.path_by_iid[selected[0]])

    def load_scene(self, path: Path) -> None:
        if not self.project:
            return
        try:
            self.scene = self.project.load(path)
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        self.transition_tree.delete(*self.transition_tree.get_children())
        self.transition_by_iid.clear()
        for index, transition in enumerate(self.scene.transitions):
            iid = str(index)
            self.transition_by_iid[iid] = transition
            self.transition_tree.insert(
                "", "end", iid=iid,
                values=(transition.source_scene, transition.destination_scene, transition.map_kind,
                        transition.map_number, transition.bc_no, transition.ptr_no,
                        transition.map_mask, transition.bgm_no,
                        f"{transition.mp_pny},{transition.mp_pnx}",
                        transition.record_file_description),
            )
        if self.scene.transitions:
            self.transition_tree.selection_set("0")
            self.transition_tree.see("0")
            self._show_transition(self.scene.transitions[0])
        else:
            for variable in self.transition_vars.values():
                variable.set("")
            self.transition_file_label.config(text=f"원본 DLL 파일명: {path.name}")
            self.transition_dest_label.config(text="목적지: 전환 레코드 없음")

        self.assign_tree.delete(*self.assign_tree.get_children())
        self.assignment_by_iid.clear()
        for index, assignment in enumerate(self.scene.assignments):
            iid = str(index)
            self.assignment_by_iid[iid] = assignment
            self.assign_tree.insert("", "end", iid=iid, text=assignment.variable,
                                    values=(assignment.value, assignment.size,
                                            assignment.segment, f"0x{assignment.source_offset:04X}",
                                            assignment.opcode, "가능" if assignment.editable else "읽기 전용"))
        self._populate_algorithm_tree()
        self.ref_tree.delete(*self.ref_tree.get_children())
        for name, count in sorted(self.scene.references.items()):
            status = "확정 변수" if name in DISPLAY_VARIABLES else "엔진 함수/전역"
            self.ref_tree.insert("", "end", values=(count, f"{name} — {status}"))
        self.strings_tree.delete(*self.strings_tree.get_children())
        self.string_by_iid.clear()
        for index, entry in enumerate(self.scene.strings):
            iid = str(index)
            self.string_by_iid[iid] = entry
            if entry.call_offset is None:
                call = "-"
            else:
                call = f"seg {entry.call_segment}:0x{entry.call_offset:04X} / ptr 0x{entry.message_pointer:04X}"
            self.strings_tree.insert(
                "", "end", iid=iid,
                values=(entry.kind, entry.segment, f"0x{entry.offset:04X}",
                        entry.capacity, call, entry.text),
            )
        lines = [
            f"파일: {path}", f"크기: {len(self.scene.data)}", f"NE 세그먼트: {len(self.scene.segments)}",
            f"Export: {len(self.scene.exports)}", f"Relocation: {len(self.scene.relocations)}",
            f"확정 즉시값: {len(self.scene.assignments)}",
            f"ENTER_PROG 전환 레코드: {len(self.scene.transitions)}",
            f"검색 문자열: {len(self.scene.strings)}",
            f"대사 문자열: {len(self.scene.dialogues)}",
            f"사용자 알고리즘: {len(self.project.custom_algorithms(path.name))}", "",
            "세그먼트:",
        ]
        lines += [f"  {seg.index}: file=0x{seg.file_offset:X}, len=0x{seg.length:X}, flags=0x{seg.flags:04X}" for seg in self.scene.segments]
        self._set_text(self.raw_text, "\n".join(lines))
        link = self.project.scene_link(path.name)
        key = link.get("map_key")
        if isinstance(key, str) and ":" in key:
            kind, number = key.split(":", 1)
            self.map_kind.set(kind)
            self.map_id.set(str(int(number)))
        else:
            self.map_kind.set("none")
            self.map_id.set("")
        self.tileset.set(link.get("tileset") or "")
        self.note.set(link.get("note") or "")
        self.status.config(text=f"씬 로드: {path.name}")

    @staticmethod
    def _set_text(widget: tk.Text, value: str) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", value)
        widget.configure(state="disabled")

    def _transition_selected(self, _event=None) -> None:
        selected = self.transition_tree.selection()
        if selected and selected[0] in self.transition_by_iid:
            self._show_transition(self.transition_by_iid[selected[0]])

    def _show_transition(self, transition: TransitionRecord) -> None:
        values = {
            "sin_no": f"0x{transition.sin_no:04X}",
            "map_number": str(transition.map_number),
            "map_mask": str(transition.map_mask),
            "bc_no": str(transition.bc_no),
            "ptr_no": str(transition.ptr_no),
            "bgm_no": str(transition.bgm_no),
            "floor_chr_no": str(transition.floor_chr_no),
            "town_no": str(transition.town_no),
            "mp_pny": str(transition.mp_pny),
            "mp_pnx": str(transition.mp_pnx),
        }
        values.update({f"chr_no{i}": str(value) for i, value in enumerate(transition.chr_nos)})
        for field, value in values.items():
            self.transition_vars[field].set(value)
        tileset_name = f"C_{transition.bc_no:03d}.BZH"
        state = "존재" if self.project and tileset_name in self.project.tile_names else "파일 없음"
        self.transition_title.config(text=f"실제 ENTER_PROG 전환 레코드 — {transition.source_scene}")
        self.transition_file_label.config(text=f"원본 DLL 파일명: {transition.source_scene}")
        self.transition_dest_label.config(
            text=(f"원본: {transition.source_scene} / 목적지: {transition.destination_scene} / "
                  f"{transition.map_key} / {tileset_name} ({state}) / "
                  f"PTR {transition.ptr_no} / MASK {transition.map_mask} / "
                  f"레코드 {transition.record_file_description}")
        )

    @staticmethod
    def _parse_number(value: str) -> int:
        value = value.strip()
        if not value:
            raise ValueError("빈 값을 저장할 수 없습니다")
        return int(value, 0)

    def save_transition(self) -> None:
        if not self.project or not self.scene:
            return
        selected = self.transition_tree.selection()
        if not selected or selected[0] not in self.transition_by_iid:
            messagebox.showinfo(APP_NAME, "수정할 전환 레코드를 선택하세요.")
            return
        transition = self.transition_by_iid[selected[0]]
        try:
            values = {field: self._parse_number(variable.get())
                      for field, variable in self.transition_vars.items()}
            self.scene = self.project.patch_transition(self.scene, transition, values)
            self.load_scene(self.scene.path)
            match_iid = next((iid for iid, item in self.transition_by_iid.items()
                              if item.record_segment == transition.record_segment
                              and item.record_offset == transition.record_offset), None)
            if match_iid is not None:
                self.transition_tree.selection_set(match_iid)
                self.transition_tree.see(match_iid)
            self.status.config(text=f"전환 레코드 저장 완료: {self.scene.path.name} {transition.record_file_description}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def edit_assignment(self) -> None:
        if not self.project or not self.scene:
            return
        selected = self.assign_tree.selection()
        if not selected or selected[0] not in self.assignment_by_iid:
            return
        assignment = self.assignment_by_iid[selected[0]]
        if not assignment.editable:
            messagebox.showinfo(APP_NAME, "이 항목은 읽기 전용입니다.")
            return
        maximum = 255 if assignment.size == 1 else 65535
        value = simpledialog.askinteger(APP_NAME, f"{assignment.variable} 새 값 (0~{maximum})", initialvalue=assignment.value, minvalue=0, maxvalue=maximum)
        if value is None:
            return
        try:
            self.scene = self.project.patch_assignment(self.scene, assignment, value)
            self.load_scene(self.scene.path)
            self.status.config(text=f"저장 완료: {assignment.variable} = {value}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    @staticmethod
    def _parse_hex_bytes(value: str) -> bytes:
        cleaned = value.replace(",", " ").replace(";", " ").replace("\n", " ").strip()
        if not cleaned:
            return b""
        tokens = []
        for token in cleaned.split():
            token = token.strip()
            if token.lower().startswith("0x"):
                token = token[2:]
            if len(token) == 0:
                continue
            if len(token) % 2:
                token = "0" + token
            if len(token) > 2:
                # Permit a compact stream such as 90CB or 0E E8 0000 CB.
                tokens.extend(token[index:index + 2] for index in range(0, len(token), 2))
            else:
                tokens.append(token)
        try:
            return bytes(int(token, 16) for token in tokens)
        except ValueError as exc:
            raise ValueError("16진수 바이트 형식이 올바르지 않습니다") from exc

    def _ask_multiline(self, title: str, prompt: str, initial: str = "",
                       width: int = 80, height: int = 16) -> Optional[str]:
        dialog = tk.Toplevel(self)
        dialog.title(title)
        dialog.transient(self)
        dialog.grab_set()
        dialog.geometry(f"{max(520, width * 8)}x{max(300, height * 22)}")
        ttk.Label(dialog, text=prompt, wraplength=760).pack(fill="x", padx=10, pady=(10, 6))
        holder = ttk.Frame(dialog)
        holder.pack(fill="both", expand=True, padx=10)
        text = tk.Text(holder, wrap="word", undo=True)
        ybar = ttk.Scrollbar(holder, orient="vertical", command=text.yview)
        xbar = ttk.Scrollbar(holder, orient="horizontal", command=text.xview)
        text.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        text.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        holder.rowconfigure(0, weight=1)
        holder.columnconfigure(0, weight=1)
        text.insert("1.0", initial)
        result: dict[str, Optional[str]] = {"value": None}

        def accept() -> None:
            result["value"] = text.get("1.0", "end-1c")
            dialog.destroy()

        buttons = ttk.Frame(dialog)
        buttons.pack(fill="x", padx=10, pady=10)
        ttk.Button(buttons, text="확인", command=accept).pack(side="right")
        ttk.Button(buttons, text="취소", command=dialog.destroy).pack(side="right", padx=(0, 6))
        dialog.bind("<Escape>", lambda _e: dialog.destroy())
        text.focus_set()
        self.wait_window(dialog)
        return result["value"]

    def _populate_algorithm_tree(self) -> None:
        self.export_tree.delete(*self.export_tree.get_children())
        self.custom_algorithm_by_iid.clear()
        self.export_by_iid.clear()
        if not self.scene or not self.project:
            return
        bindings = self.project.algorithms.get("bindings", {}).get(self.scene.path.name, {})
        for index, (name, (segment, offset)) in enumerate(
            sorted(self.scene.exports.items(), key=lambda item: (item[1][0], item[1][1], item[0]))
        ):
            iid = f"export:{index}"
            self.export_by_iid[iid] = name
            kind = "기존 알고리즘" if name.startswith("ALGO_") else (
                "씬 엔트리" if name in {"SINAL", "SINAL_INIT"} else "기타 Export"
            )
            binding = bindings.get(name)
            status = f"사용자 알고리즘 → {binding.get('target')}" if binding else "원본"
            self.export_tree.insert(
                "", "end", iid=iid,
                values=(name, segment, f"0x{offset:04X}", "-", kind, status),
            )
        for index, algorithm in enumerate(self.project.custom_algorithms(self.scene.path.name)):
            iid = f"custom:{index}"
            self.custom_algorithm_by_iid[iid] = algorithm
            targets = [name for name, info in bindings.items() if info.get("target") == algorithm.name]
            status_bits = ["활성" if algorithm.enabled else "비활성"]
            if targets:
                status_bits.append("연결: " + ", ".join(sorted(targets)))
            if algorithm.description:
                status_bits.append(algorithm.description)
            self.export_tree.insert(
                "", "end", iid=iid,
                values=(algorithm.name, algorithm.segment, f"0x{algorithm.offset:04X}",
                        algorithm.size, "사용자 알고리즘", " / ".join(status_bits)),
            )

    def _selected_export_or_custom(self) -> tuple[Optional[str], Optional[CustomAlgorithm]]:
        selected = self.export_tree.selection()
        if not selected:
            return None, None
        iid = selected[0]
        return self.export_by_iid.get(iid), self.custom_algorithm_by_iid.get(iid)

    def add_algorithm(self) -> None:
        if not self.project or not self.scene:
            return
        name = simpledialog.askstring(APP_NAME, "사용자 알고리즘 이름", parent=self)
        if name is None:
            return
        description = simpledialog.askstring(
            APP_NAME, "설명(선택)", initialvalue="", parent=self,
        )
        if description is None:
            return
        value = self._ask_multiline(
            APP_NAME,
            "16비트 x86 기계어를 16진수 바이트로 입력하세요. 마지막에 RETF(CB)가 없으면 자동으로 추가됩니다.\n"
            "예: 90 CB",
            "90 CB", height=10,
        )
        if value is None:
            return
        try:
            code = self._parse_hex_bytes(value)
            self.scene = self.project.add_custom_algorithm(self.scene, name, code, description)
            self.load_scene(self.scene.path)
            self.status.config(text=f"사용자 알고리즘 추가: {name}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def create_algo00(self) -> None:
        if not self.project or not self.scene:
            return
        if "ALGO_00" in self.scene.exports:
            messagebox.showinfo(APP_NAME, "현재 DLL에는 이미 ALGO_00이 있습니다.")
            return
        if not messagebox.askyesno(
            APP_NAME,
            f"{self.scene.path.name}에 ALGO_00 Export와 기본 RETF 루틴을 생성할까요?\n"
            "DLL 크기는 유지되며 최초 저장 시 .bak이 생성됩니다.",
        ):
            return
        try:
            self.scene = self.project.create_missing_algo00_export(self.scene)
            self.load_scene(self.scene.path)
            self.status.config(text=f"ALGO_00 생성 완료: {self.scene.path.name}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def edit_algorithm(self) -> None:
        if not self.project or not self.scene:
            return
        _export, algorithm = self._selected_export_or_custom()
        if algorithm is None:
            messagebox.showinfo(APP_NAME, "수정할 사용자 알고리즘 행을 선택하세요.")
            return
        value = self._ask_multiline(
            APP_NAME,
            f"{algorithm.name} 바이트 수정 — 예약 크기 {algorithm.size}바이트 이내",
            algorithm.code_hex, height=12,
        )
        if value is None:
            return
        try:
            code = self._parse_hex_bytes(value)
            self.scene = self.project.edit_custom_algorithm(self.scene, algorithm, code)
            self.load_scene(self.scene.path)
            self.status.config(text=f"사용자 알고리즘 수정: {algorithm.name}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def attach_algorithm(self) -> None:
        if not self.project or not self.scene:
            return
        export_name, algorithm = self._selected_export_or_custom()
        exports = sorted(name for name in self.scene.exports if name.startswith("ALGO_"))
        custom = self.project.custom_algorithms(self.scene.path.name)
        if not exports:
            messagebox.showinfo(APP_NAME, "이 DLL에는 ALGO_XX Export가 없습니다.")
            return
        if not custom:
            messagebox.showinfo(APP_NAME, "먼저 사용자 알고리즘을 추가하세요.")
            return
        if algorithm is None:
            names = [item.name for item in custom]
            selected_name = simpledialog.askstring(
                APP_NAME, "연결할 사용자 알고리즘 이름\n" + " / ".join(names),
                initialvalue=names[0], parent=self,
            )
            if selected_name is None:
                return
            algorithm = next((item for item in custom if item.name == selected_name), None)
            if algorithm is None:
                messagebox.showerror(APP_NAME, "해당 사용자 알고리즘을 찾을 수 없습니다.")
                return
        if export_name is None or not export_name.startswith("ALGO_"):
            export_name = simpledialog.askstring(
                APP_NAME, "연결할 기존 ALGO Export\n" + " / ".join(exports),
                initialvalue=exports[0], parent=self,
            )
            if export_name is None:
                return
        try:
            self.scene = self.project.attach_export(self.scene, export_name, algorithm)
            self.load_scene(self.scene.path)
            self.status.config(text=f"{export_name} → {algorithm.name} 연결 완료")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def restore_algorithm_binding(self) -> None:
        if not self.project or not self.scene:
            return
        export_name, _algorithm = self._selected_export_or_custom()
        bindings = self.project.algorithms.get("bindings", {}).get(self.scene.path.name, {})
        if export_name not in bindings:
            names = sorted(bindings)
            if not names:
                messagebox.showinfo(APP_NAME, "복원할 사용자 ALGO 연결이 없습니다.")
                return
            export_name = simpledialog.askstring(
                APP_NAME, "복원할 ALGO Export\n" + " / ".join(names),
                initialvalue=names[0], parent=self,
            )
            if export_name is None:
                return
        try:
            self.scene = self.project.restore_export_binding(self.scene, export_name)
            self.load_scene(self.scene.path)
            self.status.config(text=f"원본 ALGO 복원: {export_name}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def disable_algorithm(self) -> None:
        if not self.project or not self.scene:
            return
        _export, algorithm = self._selected_export_or_custom()
        if algorithm is None:
            messagebox.showinfo(APP_NAME, "비활성화할 사용자 알고리즘 행을 선택하세요.")
            return
        if not messagebox.askyesno(APP_NAME, f"{algorithm.name}을 RETF만 수행하도록 비활성화할까요?"):
            return
        try:
            self.scene = self.project.disable_custom_algorithm(self.scene, algorithm)
            self.load_scene(self.scene.path)
            self.status.config(text=f"사용자 알고리즘 비활성화: {algorithm.name}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def edit_string(self) -> None:
        if not self.project or not self.scene:
            return
        selected = self.strings_tree.selection()
        if not selected or selected[0] not in self.string_by_iid:
            messagebox.showinfo(APP_NAME, "수정할 문자열을 선택하세요.")
            return
        entry = self.string_by_iid[selected[0]]
        value = self._ask_multiline(
            APP_NAME,
            f"{entry.kind} 수정 — CP949 최대 {entry.capacity}바이트\n"
            f"DLL {self.scene.path.name}, seg {entry.segment}:0x{entry.offset:04X}",
            entry.text, height=10,
        )
        if value is None:
            return
        try:
            self.scene = self.project.patch_string(self.scene, entry, value)
            path = self.scene.path
            self.load_scene(path)
            self.status.config(text=f"문자열 저장: {path.name} seg {entry.segment}:0x{entry.offset:04X}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def export_current_strings(self) -> None:
        if not self.project or not self.scene:
            return
        path = filedialog.asksaveasfilename(
            title="현재 DLL 문자열 CSV 저장", defaultextension=".csv",
            initialfile=f"{self.scene.path.stem}_strings.csv",
            filetypes=(("CSV", "*.csv"),),
        )
        if not path:
            return
        try:
            count = self.project.export_strings_csv(Path(path), current=self.scene.path)
            self.status.config(text=f"현재 DLL 문자열 CSV {count}개 추출: {path}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def import_strings(self) -> None:
        if not self.project:
            return
        path = filedialog.askopenfilename(title="문자열 CSV 선택", filetypes=(("CSV", "*.csv"),))
        if not path:
            return
        try:
            count = self.project.import_strings_csv(Path(path), dialogues_only=False)
            if self.scene:
                self.load_scene(self.scene.path)
            self.status.config(text=f"문자열 CSV 적용: {count}개")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def export_dialogues(self) -> None:
        if not self.project:
            return
        path = filedialog.asksaveasfilename(
            title="전체 씬 대사 CSV 저장", defaultextension=".csv",
            initialfile="ED2_SCENA_DIALOGUES.csv", filetypes=(("CSV", "*.csv"),),
        )
        if not path:
            return
        try:
            count = self.project.export_strings_csv(Path(path), dialogues_only=True)
            self.status.config(text=f"전체 대사 CSV {count}개 추출: {path}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def import_dialogues(self) -> None:
        if not self.project:
            return
        path = filedialog.askopenfilename(title="대사 CSV 선택", filetypes=(("CSV", "*.csv"),))
        if not path:
            return
        try:
            count = self.project.import_strings_csv(Path(path), dialogues_only=True)
            if self.scene:
                self.load_scene(self.scene.path)
            self.status.config(text=f"대사 CSV 적용: {count}개")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def save_profile(self) -> None:
        if not self.project or not self.scene:
            return
        try:
            kind = self.map_kind.get()
            map_id = None
            if kind != "none":
                map_id = int(self.map_id.get(), 0)
                maximum = 39 if kind == "large" else 119
                if not 0 <= map_id <= maximum:
                    raise ValueError(f"{kind} map number must be 0..{maximum}")
            tileset = self.tileset.get()
            if tileset and tileset not in self.project.tile_names:
                raise ValueError("Unknown tileset")
            self.project.set_scene_link(self.scene.path.name, kind, map_id, tileset, self.note.get())
            self.status.config(text=f"맵 연결 프로필 저장: {self.scene.path.name}")
            self.open_project(self.project.root)
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def reload_current(self) -> None:
        if self.scene:
            self.load_scene(self.scene.path)

    def restore_current(self) -> None:
        if not self.project or not self.scene:
            return
        if not messagebox.askyesno(APP_NAME, f"{self.scene.path.name}을 최초 .bak로 복원할까요?"):
            return
        try:
            path = self.scene.path
            self.project.restore(path)
            self.load_scene(path)
            self.status.config(text=f"복원 완료: {path.name}")
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    def validate_project(self) -> None:
        if self.project:
            messagebox.showinfo(APP_NAME, json.dumps(self.project.validate(), ensure_ascii=False, indent=2))


def main() -> int:
    parser = argparse.ArgumentParser(description=f"{APP_NAME} v{VERSION}")
    parser.add_argument("game_root", nargs="?", type=Path)
    parser.add_argument("--validate", action="store_true")
    args = parser.parse_args()
    if args.validate:
        if not args.game_root:
            parser.error("--validate requires game_root")
        result = SceneProject(args.game_root).validate()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 1
    Editor(args.game_root).mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
