"""Safe NE export-table repair for ED2 SCENA DLLs missing ALGO_00."""
from __future__ import annotations

import struct
from typing import Any

from ed2_formats import FormatError, atomic_write, u16, u32


def _resident_name_records(data: bytes) -> list[tuple[str, int]]:
    ne = u32(data, 0x3C)
    pos = ne + u16(data, ne + 0x26)
    end = ne + u16(data, ne + 0x28)
    result: list[tuple[str, int]] = []
    while pos < end:
        length = data[pos]
        pos += 1
        if length == 0:
            break
        if pos + length + 2 > end:
            raise FormatError("NE resident-name table is truncated")
        name = data[pos:pos + length].decode("latin1")
        pos += length
        ordinal = u16(data, pos)
        pos += 2
        result.append((name, ordinal))
    return result


def _encode_resident_names(records: list[tuple[str, int]]) -> bytes:
    out = bytearray()
    for name, ordinal in records:
        encoded = name.encode("latin1")
        if not 1 <= len(encoded) <= 255:
            raise FormatError("Invalid NE export name length")
        out.append(len(encoded))
        out.extend(encoded)
        out.extend(struct.pack("<H", ordinal))
    out.append(0)
    return bytes(out)


def _raw_entry_records(data: bytes) -> dict[int, tuple[int, bytes]]:
    ne = u32(data, 0x3C)
    pos = ne + u16(data, ne + 0x04)
    end = pos + u16(data, ne + 0x06)
    ordinal = 1
    result: dict[int, tuple[int, bytes]] = {}
    while pos < end:
        if pos + 2 > end:
            raise FormatError("NE entry table is truncated")
        count, kind = data[pos], data[pos + 1]
        pos += 2
        if count == 0:
            break
        if kind == 0:
            ordinal += count
            continue
        size = 6 if kind == 0xFF else 3
        for _ in range(count):
            if pos + size > end:
                raise FormatError("NE entry bundle is truncated")
            result[ordinal] = (kind, bytes(data[pos:pos + size]))
            pos += size
            ordinal += 1
    return result


def _encode_entry_records(records: dict[int, tuple[int, bytes]]) -> bytes:
    if not records:
        return b"\x00\x00"
    out = bytearray()
    ordinal = 1
    maximum = max(records)
    while ordinal <= maximum:
        if ordinal not in records:
            count = 0
            while ordinal + count <= maximum and ordinal + count not in records and count < 255:
                count += 1
            out.extend((count, 0))
            ordinal += count
            continue
        kind = records[ordinal][0]
        count = 0
        payload = bytearray()
        while (
            ordinal + count <= maximum
            and ordinal + count in records
            and records[ordinal + count][0] == kind
            and count < 255
        ):
            payload.extend(records[ordinal + count][1])
            count += 1
        out.extend((count, kind))
        out.extend(payload)
        ordinal += count
    out.extend((0, 0))
    return bytes(out)


def create_missing_algo00_export(project: Any, scene: Any) -> Any:
    current = project.load(scene.path)
    if "ALGO_00" in current.exports:
        raise ValueError("이 DLL에는 이미 ALGO_00 Export가 있습니다")

    names = _resident_name_records(current.data)
    by_name = {name: ordinal for name, ordinal in names}
    required = {"WEP", "SINAL_INIT", "GETDLLDATASEG", "SINAL"}
    if not required.issubset(by_name) or by_name["WEP"] != 1:
        raise FormatError("지원되는 ED2 SCENA export 구조가 아닙니다")
    old_entries = _raw_entry_records(current.data)
    if any(ordinal not in old_entries for ordinal in by_name.values() if ordinal):
        raise FormatError("NE 이름표와 entry table ordinal이 일치하지 않습니다")

    shifted_entries: dict[int, tuple[int, bytes]] = {
        ordinal if ordinal < 2 else ordinal + 1: value
        for ordinal, value in old_entries.items()
    }
    segment_index = current.exports["SINAL_INIT"][0]
    segment = current.segments[segment_index - 1]
    code = b"\xCB"  # RETF: safe empty ALGO_00.
    seg_end = segment.file_offset + segment.length
    relocation_size = 0
    if segment.flags & 0x0100:
        if seg_end + 2 > len(current.data):
            raise FormatError("재배치 테이블이 잘렸습니다")
        relocation_size = 2 + u16(current.data, seg_end) * 8
    next_offsets = [item.file_offset for item in current.segments if item.file_offset > segment.file_offset]
    next_offset = min(next_offsets) if next_offsets else len(current.data)
    if seg_end + relocation_size + len(code) > next_offset:
        raise FormatError("ALGO_00을 넣을 코드 세그먼트 패딩이 없습니다")
    padding = current.data[seg_end + relocation_size:seg_end + relocation_size + len(code)]
    if len(padding) != len(code) or any(value not in (0x00, 0x90, 0xCC, 0xFF) for value in padding):
        raise FormatError("재배치 테이블 뒤가 안전한 패딩이 아닙니다")
    if segment.length + len(code) > 0xFFFF:
        raise FormatError("코드 세그먼트 길이가 16비트 범위를 넘습니다")
    algo_offset = segment.length
    shifted_entries[2] = (segment_index, b"\x03" + struct.pack("<H", algo_offset))

    new_names: list[tuple[str, int]] = []
    inserted = False
    for name, ordinal in names:
        if ordinal == 0:
            new_names.append((name, 0))
        elif name == "WEP":
            new_names.extend(((name, 1), ("ALGO_00", 2)))
            inserted = True
        else:
            new_names.append((name, ordinal + 1 if ordinal >= 2 else ordinal))
    if not inserted:
        raise FormatError("WEP 뒤에 ALGO_00 이름을 삽입할 수 없습니다")

    data = bytearray(current.data)
    relocation = bytes(data[seg_end:seg_end + relocation_size])
    data[seg_end:seg_end + len(code)] = code
    if relocation_size:
        data[seg_end + len(code):seg_end + len(code) + relocation_size] = relocation
    ne = u32(data, 0x3C)
    seg_table = ne + u16(data, ne + 0x22)
    length_pos = seg_table + (segment_index - 1) * 8 + 2
    struct.pack_into("<H", data, length_pos, segment.length + len(code))

    resident_rel = u16(data, ne + 0x26)
    old_modref_rel = u16(data, ne + 0x28)
    old_import_rel = u16(data, ne + 0x2A)
    old_entry_rel = u16(data, ne + 0x04)
    old_nonresident = u32(data, ne + 0x2C)
    nonresident_size = u16(data, ne + 0x20)
    modref = bytes(data[ne + old_modref_rel:ne + old_import_rel])
    imported_names = bytes(data[ne + old_import_rel:ne + old_entry_rel])
    nonresident = bytes(data[old_nonresident:old_nonresident + nonresident_size])
    resident = _encode_resident_names(new_names)
    entry = _encode_entry_records(shifted_entries)
    new_modref_rel = resident_rel + len(resident)
    new_import_rel = new_modref_rel + len(modref)
    new_entry_rel = new_import_rel + len(imported_names)
    new_nonresident = ne + new_entry_rel + len(entry)
    header_limit = min(item.file_offset for item in current.segments)
    if new_nonresident + len(nonresident) > header_limit:
        raise FormatError("확장된 NE export table이 첫 세그먼트와 겹칩니다")

    start = ne + resident_rel
    data[start:header_limit] = b"\x00" * (header_limit - start)
    pos = start
    for block in (resident, modref, imported_names, entry, nonresident):
        data[pos:pos + len(block)] = block
        pos += len(block)
    struct.pack_into("<H", data, ne + 0x28, new_modref_rel)
    struct.pack_into("<H", data, ne + 0x2A, new_import_rel)
    struct.pack_into("<H", data, ne + 0x04, new_entry_rel)
    struct.pack_into("<H", data, ne + 0x06, len(entry))
    struct.pack_into("<I", data, ne + 0x2C, new_nonresident)
    if len(data) != len(current.data):
        raise FormatError("ALGO_00 생성 중 DLL 크기가 변경되었습니다")

    atomic_write(scene.path, bytes(data))
    metadata = {
        "name": "ALGO_00_BODY", "segment": segment_index,
        "offset": algo_offset, "size": len(code), "code_hex": "cb",
        "description": "누락된 ALGO_00 기본 RETF 구현", "enabled": True,
    }
    items = project.algorithms.setdefault("scenes", {}).setdefault(scene.path.name, [])
    if not any(item.get("name") == metadata["name"] for item in items):
        items.append(metadata)
    project.save_algorithms()

    check = project.load(scene.path)
    if check.exports.get("ALGO_00") != (segment_index, algo_offset):
        raise FormatError("ALGO_00 Export 생성 검증에 실패했습니다")
    check_segment = check.segments[segment_index - 1]
    if check.data[check_segment.file_offset + algo_offset] != 0xCB:
        raise FormatError("ALGO_00 코드 검증에 실패했습니다")
    return check
