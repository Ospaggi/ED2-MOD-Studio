#!/usr/bin/env python3
"""Dragon Slayer: The Legend of Heroes II Korean UI text patch v1.5.4.

Patches exact, reviewed string slots in ED2MAIN.EXE only.  No SCENA DLL is
modified.  The file is never resized and no byte outside the declared slots is
changed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import struct
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

VERSION = "1.5.4"
SUPPORTED_SIZE = 1_848_336
BACKUP_SUFFIX = ".ui_text_patch.bak"
REPORT_NAME = "ED2_UI_TEXT_PATCH_REPORT.json"


def cp(text: str) -> bytes:
    return text.encode("cp949")


def fixed(text: str, byte_length: int, *, newline: bool = False) -> bytes:
    """Encode and space-pad to an exact byte length.

    For strings ending in LF, padding is inserted before LF so the line control
    stays at the original final byte.
    """
    raw = cp(text)
    if len(raw) > byte_length:
        raise ValueError(f"문구가 슬롯보다 깁니다: {text!r} ({len(raw)}>{byte_length})")
    if newline:
        if not raw.endswith(b"\n"):
            raise ValueError("newline=True인데 LF로 끝나지 않습니다.")
        return raw[:-1] + b" " * (byte_length - len(raw)) + b"\n"
    return raw + b" " * (byte_length - len(raw))


@dataclass(frozen=True)
class Slot:
    offset: int
    original: bytes
    desired: bytes
    purpose: str
    group: str

    def __post_init__(self) -> None:
        if len(self.original) != len(self.desired):
            raise ValueError(f"슬롯 길이 불일치: {self.purpose}")


# Core requested labels.
CORE_SLOTS = (
    Slot(0x149D52, cp("남다  "), cp("남음  "), "설정 화면 EP 표시", "core"),
    Slot(0x14B0FC, cp("남다 "), cp("남음 "), "상태 화면 다음 레벨 경험치", "core"),
    Slot(0x14B2FE, cp(" 버린다"), cp(" 버리기"), "필드 메뉴 명령", "core"),
)

# Every occurrence below means spell/magic.  Five are labels, seven are system
# UI messages.  Story dialogue in SCENA DLLs is outside this patch.
MAGIC_LABEL_SLOTS = (
    Slot(0x149AA5, cp("주문"), cp("마법"), "전투 명령 메뉴", "magic_label"),
    Slot(0x149DB7, cp("주문"), cp("마법"), "자동 전투 설정: 공격 마법", "magic_label"),
    Slot(0x149DC1, cp("주문"), cp("마법"), "자동 회복 설정: 회복 마법", "magic_label"),
    Slot(0x14B0B9, cp("주문"), cp("마법"), "상태 화면: 마법능력", "magic_label"),
    Slot(0x14B2ED, cp("주문"), cp("마법"), "필드 메뉴 명령", "magic_label"),
)

MAGIC_SYSTEM_SLOTS = (
    Slot(0x14A9E1, cp("주문"), cp("마법"), "레벨업 능력 상승 메시지", "magic_system"),
    Slot(0x14AC3D, cp("주문"), cp("마법"), "전체 마법 봉인 메시지", "magic_system"),
    Slot(0x14AC7B, cp("주문"), cp("마법"), "개별 마법 봉인 메시지", "magic_system"),
    Slot(0x14ACBA, cp("주문"), cp("마법"), "마법 반사 메시지", "magic_system"),
    Slot(0x14B170, cp("주문"), cp("마법"), "마법 학습 대상 선택", "magic_system"),
    Slot(0x14B1A7, cp("주문"), cp("마법"), "마법 습득 메시지", "magic_system"),
    Slot(0x14B1FC, cp("주문"), cp("마법"), "마법 봉인 상태 메시지", "magic_system"),
)

# Reviewed UI wording.  Only unambiguous typos, spacing errors, and inconsistent
# command-label forms are included.  Every replacement fits the original slot.
WORDING_SLOTS = (
    Slot(0x1499C4, cp("전투의 직전으로"), fixed("전투 직전으로", 15), "패배 후 선택지", "wording"),
    Slot(0x1499D4, cp("모험을 계속한다"), fixed("모험 계속하기", 15), "패배 후 선택지", "wording"),
    Slot(0x1499E5, cp("하지만 이이상은 가질수가 없습니다  "), fixed("하지만 더 이상 가질 수 없습니다", 35), "소지 한도 안내", "wording"),
    Slot(0x149A09, cp("어떤것을 버리겠습니까? "), fixed("무엇을 버리겠습니까?", 23), "버릴 물건 선택", "wording"),
    Slot(0x149A49, cp(" POINT획득  "), fixed(" POINT 획득", 12), "전투 보상 표시", "wording"),
    Slot(0x149A56, cp(" Gold 얻었습니다  "), cp(" Gold를 얻었습니다"), "전투 보상 표시", "wording"),
    Slot(0x149B42, cp("도망친다"), cp("도망가기"), "전투 설정 명령", "wording"),
    Slot(0x149CA8, cp("세이브를 중지 하겠습니다  "), fixed("세이브를 중지하겠습니다", 26), "저장 오류 안내", "wording"),
    Slot(0x149D23, cp("메세지"), cp("메시지"), "설정 메뉴 맞춤법", "wording"),
    Slot(0x149D34, cp("펑션표시"), cp("기능표시"), "설정 메뉴 용어", "wording"),
    Slot(0x149DD1, cp("전원의 설정을"), cp("모두의 설정을"), "자동 전투 일괄 설정", "wording"),
    Slot(0x149DED, cp("쓴다  "), cp("사용함"), "자동 전투 설정", "wording"),
    Slot(0x149DF4, cp("안쓴다"), cp("미사용"), "자동 전투 설정", "wording"),
    Slot(0x149E09, cp("세이브 데이타를 삭제해도 좋습니까?"), cp("세이브 데이터를 삭제해도 좋습니까?"), "저장 데이터 삭제 확인", "wording"),
    Slot(0x14A055, cp("주십시요"), cp("주십시오"), "디스크 오류 안내 1", "wording"),
    Slot(0x14A06E, cp("주십시요"), cp("주십시오"), "디스크 오류 안내 2", "wording"),
    Slot(0x14A0A9, cp("주십시요"), cp("주십시오"), "디스크 삽입 안내", "wording"),
    Slot(0x14ABDA, cp("빼았았다.\n"), cp("빼앗았다.\n"), "HP 흡수 메시지", "wording"),
    Slot(0x14ACFA, cp("최근에 하던 곳 부터 시작하기"), fixed("최근에 하던 곳부터 시작하기", 28), "시작 메뉴 띄어쓰기", "wording"),
    Slot(0x14B103, cp("기절해있다 "), fixed("기절", 11), "상태 표시: 기절", "wording"),
    Slot(0x14B216, cp("아무 것도 일어나지 않았다 \n"), fixed("아무것도 일어나지 않았다\n", 27, newline=True), "효과 없음 메시지", "wording"),
    Slot(0x14B261, cp("에게는 듣지않았다 \n"), cp("에게는 듣지 않았다\n"), "효과 없음 메시지", "wording"),
)

# Actual fixed-width place-name table in the supplied Korean ED2MAIN.EXE.
# Only spelling inconsistencies are corrected.  Location-type suffixes such as
# 마을/항/광산 are not added, and no new spacing is introduced.
# All 27 slots remain declared so v1.5.0-applied files can be normalized back
# to the compact original UI labels while retaining the four spelling fixes.
LOCATION_SLOTS = (
    Slot(0x1506AB, fixed("크루즈", 12), fixed("크루즈", 12), "지명 유지: 크루즈", "location"),
    Slot(0x1506B7, fixed("베르가", 12), fixed("베르가", 12), "지명 유지: 베르가", "location"),
    Slot(0x1506C3, fixed("네리아", 13), fixed("네리아", 13), "지명 유지: 네리아", "location"),
    Slot(0x1506D0, fixed("론도", 12), fixed("론도", 12), "지명 유지: 론도", "location"),
    Slot(0x1506DC, fixed("랄파", 11), fixed("랄파", 11), "지명 유지: 랄파", "location"),
    Slot(0x1506E7, fixed("시리카", 12), fixed("시리카", 12), "지명 유지: 시리카", "location"),
    Slot(0x15070B, fixed("요르도", 12), fixed("요르도", 12), "지명 유지: 요르도", "location"),
    Slot(0x150730, fixed("세레", 12), fixed("세레", 12), "지명 유지: 세레", "location"),
    Slot(0x15073C, fixed("스엘", 12), fixed("스엘", 12), "지명 유지: 스엘", "location"),
    Slot(0x150748, fixed("암다", 12), fixed("암다", 12), "지명 유지: 암다", "location"),
    Slot(0x15076B, fixed("루드라", 13), fixed("루드라", 13), "지명 유지: 루드라", "location"),
    Slot(0x150778, fixed("가울", 11), fixed("카울", 11), "지명 철자: 가울 → 카울", "location"),
    Slot(0x150790, fixed("리셀", 12), fixed("리셀", 12), "지명 유지: 리셀", "location"),
    Slot(0x1507A7, fixed("파에트", 12), fixed("파에토", 12), "지명 철자: 파에트 → 파에토", "location"),
    Slot(0x1507CB, fixed("팡가스", 12), fixed("판가스", 12), "지명 철자: 팡가스 → 판가스", "location"),
    Slot(0x150836, fixed("곶의동굴", 11), fixed("곶의동굴", 11), "지명 유지: 곶의동굴", "location"),
    Slot(0x150841, fixed("시련의동굴", 13), fixed("시련의동굴", 13), "지명 유지: 시련의동굴", "location"),
    Slot(0x15084E, fixed("왕가의묘", 12), fixed("왕가의묘", 12), "지명 유지: 왕가의묘", "location"),
    Slot(0x15085A, fixed("늑대의입", 12), fixed("늑대의입", 12), "지명 유지: 늑대의입", "location"),
    Slot(0x150866, fixed("나락의입", 11), fixed("나락의입", 11), "지명 유지: 나락의입", "location"),
    Slot(0x150871, fixed("아네스의탑", 11), fixed("아네스의탑", 11), "지명 유지: 아네스의탑", "location"),
    Slot(0x15087C, fixed("사피아의호수", 14), fixed("사피아의호수", 14), "지명 유지: 사피아의호수", "location"),
    Slot(0x15088A, fixed("모간의집", 11), fixed("모간의집", 11), "지명 유지: 모간의집", "location"),
    Slot(0x150895, fixed("네사의면토", 11), fixed("네사의변토", 11), "지명 철자: 네사의면토 → 네사의변토", "location"),
    Slot(0x1508A0, fixed("그로스토스성", 14), fixed("그로스토스성", 14), "지명 유지: 그로스토스성", "location"),
    Slot(0x1508AE, fixed("중앙정원", 12), fixed("중앙정원", 12), "지명 유지: 중앙정원", "location"),
    Slot(0x1508D2, fixed("옥좌의방", 11), fixed("옥좌의방", 11), "지명 유지: 옥좌의방", "location"),
)

# Values produced by v1.5.0.  They are accepted only as migration inputs and
# are normalized to the compact v1.5.1 labels above.
LEGACY_LOCATION_V150 = {
    0x1506AB: fixed("크루즈 마을", 12),
    0x1506B7: fixed("베르가 광산", 12),
    0x1506C3: fixed("네리아 항", 13),
    0x1506D0: fixed("론도 항", 12),
    0x1506DC: fixed("랄파 항", 11),
    0x1506E7: fixed("시리카 마을", 12),
    0x15070B: fixed("요르도 항", 12),
    0x150730: fixed("세레 마을", 12),
    0x15073C: fixed("스엘 마을", 12),
    0x150748: fixed("암다 마을", 12),
    0x15076B: fixed("루드라 항", 13),
    0x150778: fixed("카울 마을", 11),
    0x150790: fixed("리셀 항", 12),
    0x1507A7: fixed("파에토 마을", 12),
    0x1507CB: fixed("판가스", 12),
    0x150836: fixed("곶의 동굴", 11),
    0x150841: fixed("시련의 동굴", 13),
    0x15084E: fixed("왕가의 무덤", 12),
    0x15085A: fixed("늑대의 입", 12),
    0x150866: fixed("나락의 입", 11),
    0x150871: fixed("아네스의 탑", 11),
    0x15087C: fixed("사피아의 호수", 14),
    0x15088A: fixed("모간의 집", 11),
    0x150895: fixed("네사의 변토", 11),
    0x1508A0: fixed("그로스토스 성", 14),
    0x1508AE: fixed("중앙 정원", 12),
    0x1508D2: fixed("옥좌의 방", 11),
}

ALL_SLOTS = (
    CORE_SLOTS + MAGIC_LABEL_SLOTS + MAGIC_SYSTEM_SLOTS + WORDING_SLOTS + LOCATION_SLOTS
)


# 전투 상태 표시는 원본의 한 글자 약어 방식을 그대로 사용한다.
#
# 이전 v1.5.0~v1.5.3 및 v1.5.2-fix1은 두 글자 상태명을 출력하기 위해
# 원본 wrapper/helper를 점프로 바꾸고 같은 세그먼트의 0 영역에 확장 코드를
# 기록했다. v1.5.4는 이 변경을 모두 제거하여 다음 원본 표시로 복구한다.
#   독 / 묵 / 잠 / 혼 / 수 / 반
#
# 지명과 기타 UI 문구 수정은 그대로 유지한다.
STATUS_WRAPPER_OFFSET = 0x15E2DE
STATUS_WRAPPER_ORIGINAL = bytes.fromhex("56 51 50")
# v1.5.2-fix1에서 사용한 wrapper->cave near jump.
STATUS_WRAPPER_FIX1_PATCHED = bytes.fromhex("E9 1F 74")

STATUS_HELPER_OFFSET = 0x15E306
STATUS_HELPER_ORIGINAL = bytes.fromhex(
    "AC 84 C4 75 06 83 C6 03 E2 F6 CB 87 FA A4 A5 87 FA CB"
)
# v1.5.0~v1.5.3에서 사용한 helper->cave near jump.
STATUS_HELPER_LEGACY_PATCHED = bytes.fromhex(
    "E9 F7 73 90 90 90 90 90 90 90 90 90 90 90 90 90 90 90"
)

STATUS_CAVE_OFFSET = 0x155700
STATUS_CAVE_CODE_V151 = bytes.fromhex(
    "AC 84 E0 75 06 83 C6 03 E2 F6 CB "
    "3C 40 74 0B 3C 20 74 17 87 D7 A4 A5 87 D7 CB "
    "87 D7 8A 04 AA B8 B9 DD AB B8 BB E7 AB 87 D7 CB "
    "87 D7 8A 04 AA B8 B9 E6 AB B8 BE EE AB 87 D7 CB"
)
STATUS_CAVE_CODE_V152 = bytes.fromhex(
    "AC 84 E0 75 06 83 C6 03 E2 F6 CB "
    "3C 40 74 17 3C 20 74 23 3C 08 74 2F 3C 10 74 3B 3C 02 74 47 "
    "87 D7 A4 A5 87 D7 CB "
    "87 D7 8A 04 AA B8 B9 DD AB B8 BB E7 AB 87 D7 CB "
    "87 D7 8A 04 AA B8 B9 E6 AB B8 BE EE AB 87 D7 CB "
    "87 D7 8A 04 AA B8 BC F6 AB B8 B8 E9 AB 87 D7 CB "
    "87 D7 8A 04 AA B8 C8 A5 AB B8 B6 F5 AB 87 D7 CB "
    "87 D7 8A 04 AA B8 C4 A7 AB B8 B9 AC AB 87 D7 CB"
)
STATUS_CAVE_CODE_V153 = bytes.fromhex(
    "AC 84 C4 75 06 83 C6 03 E2 F6 CB 3C 40 74 17 3C 20 74 28 3C 08 74 39 3C "
    "10 74 4A 3C 02 74 5B 87 FA A4 A5 87 FA CB 83 EA 02 87 FA AC AA B8 B9 DD "
    "AB B8 BB E7 AB 83 C6 02 87 FA CB 83 EA 02 87 FA AC AA B8 BC F6 AB B8 BE "
    "EE AB 83 C6 02 87 FA CB 83 EA 02 87 FA AC AA B8 BC F6 AB B8 B8 E9 AB 83 "
    "C6 02 87 FA CB 83 EA 02 87 FA AC AA B8 C8 A5 AB B8 B6 F5 AB 83 C6 02 87 "
    "FA CB 83 EA 02 87 FA AC AA B8 C4 A7 AB B8 B9 AC AB 83 C6 02 87 FA CB"
)
STATUS_CAVE_CODE_FIX1 = bytes.fromhex(
    "56 51 50 8A 65 24 8A 05 24 04 75 02 B0 80 08 C4 88 E0 24 7F 3C 08 74 38"
    "3C 10 74 48 3C 02 74 58 3C 40 74 68 3C 20 74 78 BE D2 3C B9 09 00 E8 0D"
    "00 F6 C4 04 75 04 49 E8 04 00 58 59 5E CB AC 84 C4 75 06 83 C6 03 E2 F6"
    "C3 87 D7 A4 A5 87 D7 C3 87 D7 B0 1A AA B8 BC F6 AB B8 B8 E9 AB B0 1D AA"
    "87 D7 EB D6 87 D7 B0 1A AA B8 C8 A5 AB B8 B6 F5 AB B0 1D AA 87 D7 EB C2"
    "87 D7 B0 1A AA B8 C4 A7 AB B8 B9 AC AB B0 1D AA 87 D7 EB AE 87 D7 B0 1E"
    "AA B8 B9 DD AB B8 BB E7 AB B0 1D AA 87 D7 EB 9A 87 D7 B0 1E AA B8 B9 E6"
    "AB B8 BE EE AB B0 1D AA 87 D7 EB 86"
)
STATUS_CAVE_SIZE = len(STATUS_CAVE_CODE_FIX1)
STATUS_CAVE_ORIGINAL = b"\x00" * STATUS_CAVE_SIZE
STATUS_CAVE_V151_PADDED = STATUS_CAVE_CODE_V151 + b"\x00" * (
    STATUS_CAVE_SIZE - len(STATUS_CAVE_CODE_V151)
)
STATUS_CAVE_V152_PADDED = STATUS_CAVE_CODE_V152 + b"\x00" * (
    STATUS_CAVE_SIZE - len(STATUS_CAVE_CODE_V152)
)
STATUS_CAVE_V153_PADDED = STATUS_CAVE_CODE_V153 + b"\x00" * (
    STATUS_CAVE_SIZE - len(STATUS_CAVE_CODE_V153)
)

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def resolve_exe(path: Path) -> Path:
    path = path.expanduser().resolve()
    exe = path / "ED2MAIN.EXE" if path.is_dir() else path
    if not exe.is_file() or exe.name.upper() != "ED2MAIN.EXE":
        raise FileNotFoundError(f"ED2MAIN.EXE를 찾을 수 없습니다: {exe}")
    return exe


def validate_ne(data: bytes) -> None:
    if len(data) != SUPPORTED_SIZE:
        raise ValueError(f"지원하지 않는 파일 크기입니다: {len(data):,} bytes")
    if data[:2] != b"MZ":
        raise ValueError("MZ 실행 파일이 아닙니다.")
    ne_off = struct.unpack_from("<I", data, 0x3C)[0]
    if ne_off + 2 > len(data) or data[ne_off:ne_off + 2] != b"NE":
        raise ValueError("NE 헤더를 찾을 수 없습니다.")


def selected_slots(labels_only: bool, no_wording: bool) -> tuple[Slot, ...]:
    slots = CORE_SLOTS + MAGIC_LABEL_SLOTS + LOCATION_SLOTS
    if not labels_only:
        slots += MAGIC_SYSTEM_SLOTS
    if not no_wording:
        slots += WORDING_SLOTS
    return slots


def accepted_values(slot: Slot) -> tuple[bytes, ...]:
    # Original and desired are both valid input states, making reapplication and
    # migration from older patch versions safe.
    values = [slot.original, slot.desired]
    if slot.offset == 0x14B103:
        values.append(cp("기절해 있다"))  # v1.2.0
        values.append(cp("기절 해있다"))  # spacing variant seen in some installs
    if slot.group == "location" and slot.offset in LEGACY_LOCATION_V150:
        values.append(LEGACY_LOCATION_V150[slot.offset])
    return tuple(dict.fromkeys(values))


def inspect_status_patch(data: bytes) -> dict[str, str]:
    wrapper = data[STATUS_WRAPPER_OFFSET:STATUS_WRAPPER_OFFSET + len(STATUS_WRAPPER_ORIGINAL)]
    helper = data[STATUS_HELPER_OFFSET:STATUS_HELPER_OFFSET + len(STATUS_HELPER_ORIGINAL)]
    cave = data[STATUS_CAVE_OFFSET:STATUS_CAVE_OFFSET + STATUS_CAVE_SIZE]

    original_state = (
        wrapper == STATUS_WRAPPER_ORIGINAL
        and helper == STATUS_HELPER_ORIGINAL
        and cave == STATUS_CAVE_ORIGINAL
    )
    legacy_state = (
        wrapper == STATUS_WRAPPER_ORIGINAL
        and helper == STATUS_HELPER_LEGACY_PATCHED
        and cave in (STATUS_CAVE_V151_PADDED, STATUS_CAVE_V152_PADDED, STATUS_CAVE_V153_PADDED)
    )
    fix1_state = (
        wrapper == STATUS_WRAPPER_FIX1_PATCHED
        and helper == STATUS_HELPER_ORIGINAL
        and cave == STATUS_CAVE_CODE_FIX1
    )
    if not (original_state or legacy_state or fix1_state):
        raise ValueError(
            "상태 출력 코드 조합이 예상과 다릅니다: "
            f"wrapper={wrapper.hex(' ')}, helper={helper.hex(' ')}, "
            f"cave_sha256={sha256(cave)}"
        )

    if original_state:
        state = "original_one_character"
    elif fix1_state:
        state = "v1.5.2-fix1_two_character"
    elif cave == STATUS_CAVE_V153_PADDED:
        state = "v1.5.3_two_character"
    elif cave == STATUS_CAVE_V152_PADDED:
        state = "v1.5.2_two_character"
    else:
        state = "v1.5.0_or_v1.5.1_two_character"
    return {
        "state": state,
        "wrapper": wrapper.hex(" "),
        "helper": helper.hex(" "),
        "cave_sha256": sha256(cave),
    }

def inspect(data: bytes) -> list[dict[str, object]]:
    validate_ne(data)
    inspect_status_patch(data)
    rows: list[dict[str, object]] = []
    for slot in ALL_SLOTS:
        current = data[slot.offset:slot.offset + len(slot.original)]
        if current not in accepted_values(slot):
            raise ValueError(
                f"0x{slot.offset:X} 문구가 예상과 다릅니다: "
                f"{current.hex(' ')} ({slot.purpose})"
            )
        rows.append({
            "offset": slot.offset,
            "group": slot.group,
            "purpose": slot.purpose,
            "current": current.decode("cp949"),
            "original": slot.original.decode("cp949"),
            "desired": slot.desired.decode("cp949"),
            "length": len(slot.original),
        })
    return rows


def atomic_write(path: Path, data: bytes) -> None:
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as fp:
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass
        raise


def build_target(data: bytes, labels_only: bool, no_wording: bool) -> tuple[bytes, list[dict[str, object]]]:
    selected = {slot.offset: slot for slot in selected_slots(labels_only, no_wording)}
    buf = bytearray(data)
    changes: list[dict[str, object]] = []

    # Selected slots go to desired state.  Unselected magic-system slots are
    # normalized back to 주문 so --labels-only repairs the old broad patch.
    for slot in ALL_SLOTS:
        if slot.offset in selected:
            wanted = slot.desired
        elif slot.group == "magic_system":
            wanted = slot.original
        else:
            continue
        current = bytes(buf[slot.offset:slot.offset + len(slot.original)])
        if current != wanted:
            buf[slot.offset:slot.offset + len(wanted)] = wanted
            changes.append({
                "offset": slot.offset,
                "group": slot.group,
                "purpose": slot.purpose,
                "before": current.decode("cp949"),
                "after": wanted.decode("cp949"),
                "byte_length": len(wanted),
            })
    # 모든 두 글자 상태 확장을 제거하고 원본 한 글자 상태 출력을 복구한다.
    wrapper = bytes(buf[STATUS_WRAPPER_OFFSET:STATUS_WRAPPER_OFFSET + len(STATUS_WRAPPER_ORIGINAL)])
    helper = bytes(buf[STATUS_HELPER_OFFSET:STATUS_HELPER_OFFSET + len(STATUS_HELPER_ORIGINAL)])
    cave = bytes(buf[STATUS_CAVE_OFFSET:STATUS_CAVE_OFFSET + STATUS_CAVE_SIZE])

    if wrapper != STATUS_WRAPPER_ORIGINAL:
        buf[STATUS_WRAPPER_OFFSET:STATUS_WRAPPER_OFFSET + len(STATUS_WRAPPER_ORIGINAL)] = STATUS_WRAPPER_ORIGINAL
        changes.append({
            "offset": STATUS_WRAPPER_OFFSET, "group": "battle_status",
            "purpose": "전투 상태 wrapper를 원본 한 글자 출력으로 복구",
            "before": "두 글자 상태 확장 루틴으로 점프",
            "after": "원본 wrapper",
            "byte_length": len(STATUS_WRAPPER_ORIGINAL),
        })

    if helper != STATUS_HELPER_ORIGINAL:
        buf[STATUS_HELPER_OFFSET:STATUS_HELPER_OFFSET + len(STATUS_HELPER_ORIGINAL)] = STATUS_HELPER_ORIGINAL
        changes.append({
            "offset": STATUS_HELPER_OFFSET, "group": "battle_status",
            "purpose": "전투 상태 helper를 원본 한 글자 출력으로 복구",
            "before": "두 글자 상태 확장 영역으로 점프",
            "after": "원본 상태 테이블 스캔 helper",
            "byte_length": len(STATUS_HELPER_ORIGINAL),
        })

    if cave != STATUS_CAVE_ORIGINAL:
        buf[STATUS_CAVE_OFFSET:STATUS_CAVE_OFFSET + STATUS_CAVE_SIZE] = STATUS_CAVE_ORIGINAL
        changes.append({
            "offset": STATUS_CAVE_OFFSET, "group": "battle_status",
            "purpose": "두 글자 전투 상태 확장 코드 제거",
            "before": "이전 버전 상태 출력 확장 코드",
            "after": "원본 미사용 00 영역",
            "byte_length": STATUS_CAVE_SIZE,
        })
    return bytes(buf), changes


def patch(exe: Path, *, check_only: bool, labels_only: bool, no_wording: bool) -> int:
    before = exe.read_bytes()
    inspect(before)
    target, changes = build_target(before, labels_only, no_wording)

    mode = "레이블 5곳만" if labels_only else "마법 관련 UI 12곳 전체"
    wording = "제외" if no_wording else f"포함({len(WORDING_SLOTS)}곳)"
    print(f"대상: {exe}")
    print(f"모드: {mode}, UI 문장 교정 {wording}, 지명 슬롯 27곳 검증, 철자 4곳 통일")
    print(f"변경 필요: {len(changes)}곳")

    if check_only:
        for row in changes:
            print(f"  0x{row['offset']:X}: {row['before']!r} -> {row['after']!r} ({row['purpose']})")
        return 0
    if not changes:
        print("이미 요청한 패치 상태입니다.")
        return 0

    backup = exe.with_name(exe.name + BACKUP_SUFFIX)
    if not backup.exists():
        shutil.copy2(exe, backup)
        print(f"백업 생성: {backup.name}")

    if len(target) != len(before):
        raise RuntimeError("패치 후 파일 크기가 달라졌습니다.")

    allowed: set[int] = set()
    for row in changes:
        off = int(row["offset"])
        allowed.update(range(off, off + int(row["byte_length"])))
    actual = {i for i, (a, b) in enumerate(zip(before, target)) if a != b}
    if not actual.issubset(allowed):
        raise RuntimeError("선언된 문구 슬롯 밖의 바이트가 변경되었습니다.")

    # Reparse all slots before committing.
    inspect(target)
    atomic_write(exe, target)
    reread = exe.read_bytes()
    if reread != target:
        raise RuntimeError("저장 후 바이트 재검증에 실패했습니다.")

    report = {
        "patch_version": VERSION,
        "target": str(exe),
        "backup": str(backup),
        "mode": {
            "labels_only": labels_only,
            "magic_scope": 5 if labels_only else 12,
            "wording_fixes": 0 if no_wording else len(WORDING_SLOTS),
            "battle_status_labels": {
                "0x01": "독", "0x02": "묵", "0x08": "잠",
                "0x10": "혼", "0x20": "수", "0x40": "반",
            },
            "battle_status_layout": {
                "mode": "original_one_character_abbreviations",
                "expanded_status_code_removed": True,
                "following_mp_position": "original",
            },
            "location_labels": [slot.desired.decode("cp949").rstrip() for slot in LOCATION_SLOTS],
        },
        "size_before": len(before),
        "size_after": len(target),
        "sha256_before": sha256(before),
        "sha256_after": sha256(target),
        "changes": changes,
        "validation": {
            "mz_ne_valid": True,
            "file_size_unchanged": len(before) == len(target),
            "changes_limited_to_declared_slots": actual.issubset(allowed),
            "saved_bytes_match": reread == target,
        },
    }
    report_path = exe.parent / REPORT_NAME
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print("패치 완료:")
    for row in changes:
        print(f"  0x{row['offset']:X}: {row['before']!r} -> {row['after']!r} ({row['purpose']})")
    print(f"보고서: {report_path.name}")
    return 0


def restore(exe: Path) -> int:
    backup = exe.with_name(exe.name + BACKUP_SUFFIX)
    if not backup.is_file():
        print(f"백업을 찾을 수 없습니다: {backup}", file=sys.stderr)
        return 2
    data = backup.read_bytes()
    inspect(data)
    atomic_write(exe, data)
    if exe.read_bytes() != data:
        raise RuntimeError("복원 후 재검증에 실패했습니다.")
    print(f"복원 완료: {exe}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="영웅전설 2 한국판 UI 문구 정밀 패치")
    ap.add_argument("path", nargs="?", default=".", help="게임 폴더 또는 ED2MAIN.EXE")
    ap.add_argument(
        "--labels-only", action="store_true",
        help="주문→마법은 메뉴·설정·상태 레이블 5곳만 적용하고 시스템 문장 7곳은 주문으로 유지",
    )
    ap.add_argument("--no-wording", action="store_true", help="추가 UI 문장 교정을 적용하지 않음")
    action = ap.add_mutually_exclusive_group()
    action.add_argument("--check", action="store_true", help="검사만 수행")
    action.add_argument("--restore", action="store_true", help="이 패치 적용 전 파일로 복원")
    args = ap.parse_args()
    try:
        exe = resolve_exe(Path(args.path))
        if args.restore:
            return restore(exe)
        return patch(
            exe,
            check_only=args.check,
            labels_only=args.labels_only,
            no_wording=args.no_wording,
        )
    except Exception as exc:
        print(f"오류: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
