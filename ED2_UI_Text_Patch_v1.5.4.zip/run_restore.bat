@echo off
python "%~dp0patch_ed2_ui_text.py" "%~1" --restore
pause
